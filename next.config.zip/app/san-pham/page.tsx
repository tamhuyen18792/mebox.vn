"use client"

import { useState } from "react"
import { Phone, Mail, MapPin, Menu, X } from "lucide-react"

export default function SanPhamPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <div className="min-h-screen bg-[#f8f9fa] font-sans">
      {/* TOP BAR */}
      <div className="bg-gradient-to-r from-[#1a1a2e] via-[#1e3a5f] to-[#1a1a2e] text-white text-xs md:text-sm">
        {/* Mobile Layout */}
        <div className="flex md:hidden px-3 py-2.5 justify-between items-center">
          <a href="tel:0373122528" className="flex items-center gap-1.5 text-[#22c55e] font-semibold">
            <Phone className="w-3.5 h-3.5" /> 0373 122 528
          </a>
          <div className="flex items-center gap-3">
            <a href="/chinh-sach-ban-hang" className="text-[#ffd700] font-medium hover:text-white transition-colors">{"Chính sách"}</a>
            <a href="/gioi-thieu" className="text-white/80 hover:text-white transition-colors">{"Giới thiệu"}</a>
          </div>
        </div>
        {/* Desktop Layout */}
        <div className="hidden md:flex justify-between items-center px-4 lg:px-10 py-2.5">
          <div className="flex items-center gap-6 lg:gap-8">
            <a href="tel:0373122528" className="flex items-center gap-2 hover:text-[#22c55e] transition-colors group">
              <div className="w-7 h-7 bg-[#22c55e] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-semibold">0373 122 528 - 0865 108 823</span>
            </a>
          </div>
          <div className="flex items-center gap-1">
            <a href="/" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Trang chủ"}</a>
            <a href="/chinh-sach-ban-hang" className="px-3 py-1.5 rounded-full text-[#ffd700] font-semibold text-xs hover:bg-white/10 transition-colors">{"Chính sách bán hàng"}</a>
            <a href="/gioi-thieu" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Giới thiệu"}</a>
            <a href="/san-pham" className="px-3 py-1.5 rounded-full bg-[#22c55e] text-white font-semibold text-xs hover:bg-[#16a34a] transition-colors">{"Sản phẩm"}</a>
            <a href="/tin-tuc" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Tin tức"}</a>
            <a href="/lien-he" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Liên hệ"}</a>
          </div>
        </div>
      </div>

      {/* NAVBAR */}
      <nav className="bg-white shadow-md sticky top-0 z-50">
        <div className="px-4 lg:px-10 flex items-center justify-between h-16 md:h-[70px]">
          <a href="/" className="flex items-center gap-2">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E1%BA%A3nh%20logo-s6wIBI1jXip1zwNmoCzX4xHCxJCHHM.jpg" 
              alt="MeBox Logo" 
              className="w-9 h-9 md:w-11 md:h-11 rounded-full object-cover shadow-md" 
            />
            <span className="text-xl md:text-2xl font-black text-[#1a1a2e]">
              Me<span className="text-[#22c55e]">Box</span>
            </span>
          </a>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center gap-1 border-b-[3px] border-transparent">
            {["Trang chủ", "Chính sách bán hàng", "Sản phẩm", "Giới thiệu", "Tin tức", "Liên hệ"].map((item, i) => (
              <a
                key={item}
                href={item === "Trang chủ" ? "/" : item === "Chính sách bán hàng" ? "/chinh-sach-ban-hang" : item === "Giới thiệu" ? "/gioi-thieu" : item === "Sản phẩm" ? "/san-pham" : item === "Tin tức" ? "/tin-tuc" : item === "Liên hệ" ? "/lien-he" : "#"}
                className={`px-3 lg:px-4 py-[18px] text-[12px] lg:text-[13.5px] font-semibold border-b-[3px] -mb-[3px] transition-colors ${
                  i === 2 ? "text-[#22c55e] border-[#22c55e]" : "text-[#333] border-transparent hover:text-[#22c55e] hover:border-[#22c55e]"
                }`}
              >
                {item}
              </a>
            ))}
          </div>

          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t shadow-lg">
            {["Trang chủ", "Chính sách bán hàng", "Sản phẩm", "Giới thiệu", "Tin tức", "Liên hệ"].map((item, i) => (
              <a
                key={item}
                href={item === "Trang chủ" ? "/" : item === "Chính sách bán hàng" ? "/chinh-sach-ban-hang" : item === "Giới thiệu" ? "/gioi-thieu" : item === "Sản phẩm" ? "/san-pham" : item === "Tin tức" ? "/tin-tuc" : item === "Liên hệ" ? "/lien-he" : "#"}
                onClick={() => setMobileMenuOpen(false)}
                className={`block px-4 py-3 text-sm font-semibold border-b border-[#f0f0f0] ${
                  i === 2 ? "text-[#22c55e]" : "text-[#333]"
                }`}
              >
                {item}
              </a>
            ))}
          </div>
        )}
      </nav>

      {/* BANNER */}
      <section className="bg-gradient-to-r from-[#1a5276] to-[#2471a3] py-10 md:py-16 px-4 md:px-10 text-white text-center">
        <h1 className="text-2xl md:text-4xl font-black uppercase mb-3">
          Sản Phẩm <span className="text-[#ffd700]">Hộp Carton</span>
        </h1>
        <p className="text-sm md:text-base text-white/90 max-w-2xl mx-auto">
          Bảng giá chi tiết các loại hộp carton chất lượng cao của MeBox
        </p>
        <div className="flex items-center justify-center gap-2 mt-4 text-sm">
          <a href="/" className="hover:text-[#ffd700] transition-colors">Trang chủ</a>
          <span>/</span>
          <span className="text-[#ffd700]">Sản phẩm</span>
        </div>
      </section>

      {/* WHOLESALE PRICING */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-gradient-to-br from-[#f0fdf4] to-white">
        <div className="max-w-[1400px] mx-auto mb-3 md:mb-4">
          <div className="bg-[#1a5276] rounded-t-xl px-6 md:px-10 py-6 md:py-8 text-center shadow-lg">
            <h2 className="text-xl md:text-2xl font-black uppercase text-[#ffd700]">
              BẢNG GIÁ KHÁCH SỈ
            </h2>
            <p className="text-white text-sm md:text-base mt-3 font-medium">{"Ưu đãi đặc biệt dành cho đối tác và khách hàng mua số lượng lớn"}</p>
            <p className="text-[#ffd700] text-xs md:text-sm mt-2 font-semibold">{"(Giá đã bao gồm VAT)"}</p>
          </div>
        </div>
        <div className="max-w-[1400px] mx-auto">
          <img 
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/b%E1%BA%A3ng%20b%C3%A1o%20gi%C3%A1%20th%C3%A1ng%204.2026-zbaGb9VQAKcNCIZIONULBM3kQK8nqd.jpg"
            alt="Bảng báo giá hộp carton MeBox tháng 4/2026"
            className="w-full h-auto rounded-lg shadow-lg"
          />
        </div>

        {/* Additional Info */}
        <div className="mt-8 md:mt-10 text-center">
          <p className="text-[13px] md:text-sm text-[#666] mb-4">
            {"Bạn cần đơn hàng lớn hơn hoặc có yêu cầu đặc biệt? "}
            <a href="tel:0373122528" className="text-[#22c55e] font-semibold hover:underline">
              Liên hệ với chúng tôi
            </a>
          </p>
          <div className="inline-flex flex-col sm:flex-row items-center gap-3 md:gap-6 bg-white px-4 md:px-6 py-3 md:py-4 rounded-lg shadow">
            <div className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-[#22c55e]" />
              <span className="font-bold text-[#333] text-sm md:text-base">0373 122 528 - 0865 108 823</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-[#22c55e]" />
              <span className="font-bold text-[#333] text-sm md:text-base">salesmebox.vn@gmail.com</span>
            </div>
          </div>
        </div>

        {/* QUY TRÌNH MUA HÀNG */}
        <div className="max-w-[1400px] mx-auto mt-6 md:mt-8">
          <img 
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/QUY%20TRINH%20MUA%20H%C3%80NG-pKRynr2V0YIEnl3sM3bTEioT3VlJ6l.jpg"
            alt="Quy trình mua hàng MeBox: Tư vấn - Báo giá - Xác nhận - Sản xuất - Giao hàng - Thanh toán"
            className="w-full h-auto rounded-lg shadow-lg"
          />
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-10 md:py-14 px-4 md:px-10 bg-gradient-to-r from-[#1a5276] to-[#2471a3] text-white text-center">
        <h2 className="text-xl md:text-2xl font-black uppercase mb-4">
          {"Liên hệ ngay để được tư vấn"}
        </h2>
        <p className="text-sm md:text-base text-white/90 mb-6 max-w-xl mx-auto">
          {"Đội ngũ MeBox luôn sẵn sàng hỗ trợ bạn 24/7"}
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <a
            href="tel:0373122528"
            className="inline-flex items-center justify-center gap-2 bg-[#22c55e] text-white px-6 py-3 rounded-full font-bold hover:bg-[#16a34a] transition-colors shadow-lg"
          >
            <Phone className="w-5 h-5" />
            Gọi ngay: 0373 122 528
          </a>
          <a
            href="https://zalo.me/0373122528"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center justify-center gap-2 bg-[#0068ff] text-white px-6 py-3 rounded-full font-bold hover:bg-[#0050cc] transition-colors shadow-lg"
          >
            Chat Zalo
          </a>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#1a1a2e] text-[#ccc] py-8 md:py-12 px-4 md:px-10">
        <div className="max-w-[1400px] mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <img 
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E1%BA%A3nh%20logo-s6wIBI1jXip1zwNmoCzX4xHCxJCHHM.jpg" 
                alt="MeBox Logo" 
                className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover" 
              />
              <span className="text-lg font-black text-white">
                Me<span className="text-[#22c55e]">Box</span>
              </span>
            </div>
            <p className="text-[12px] md:text-[12.5px] leading-relaxed mb-4">
              {"MeBox - Chuyên cung cấp các giải pháp gia công bao bì chất lượng cao, phục vụ cho hàng trăm doanh nghiệp, hộ kinh doanh và các shop Online."}
            </p>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">{"Mục lục"}</h5>
            <ul className="space-y-2 text-[11px] md:text-xs">
              <li><a href="/" className="hover:text-[#22c55e] transition-colors">{"Trang chủ"}</a></li>
              <li><a href="/gioi-thieu" className="hover:text-[#22c55e] transition-colors">{"Giới thiệu"}</a></li>
              <li><a href="/san-pham" className="hover:text-[#22c55e] transition-colors">{"Sản phẩm"}</a></li>
              <li><a href="#" className="hover:text-[#22c55e] transition-colors">{"Tin tức"}</a></li>
              <li><a href="#" className="hover:text-[#22c55e] transition-colors">{"Liên hệ"}</a></li>
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">{"Sản phẩm"}</h5>
            <ul className="space-y-2 text-[11px] md:text-xs">
              <li><a href="#" className="hover:text-[#22c55e] transition-colors">{"Hộp carton"}</a></li>
              <li><a href="#" className="hover:text-[#22c55e] transition-colors">{"Túi giấy"}</a></li>
              <li><a href="#" className="hover:text-[#22c55e] transition-colors">{"Băng keo"}</a></li>
              <li><a href="#" className="hover:text-[#22c55e] transition-colors">{"Xốp chống sốc"}</a></li>
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">{"Liên hệ"}</h5>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <MapPin className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              <div>
                <p>{"Văn phòng: 125 đường số 5, KDC Vĩnh Lộc, Phường Bình Tân, TP. Hồ Chí Minh"}</p>
                <p className="mt-1">{"Nhà Máy: Lô A7, CCN Nhị Xuân, Xã Xuân Thới Sơn, TP. Hồ Chí Minh"}</p>
              </div>
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <Phone className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              0373 122 528 - 0865 108 823
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs">
              <Mail className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              salesmebox.vn@gmail.com
            </div>
          </div>
        </div>
        <div className="max-w-[1400px] mx-auto mt-6 md:mt-8 pt-4 md:pt-6 border-t border-[#333] text-center text-[10px] md:text-xs text-[#888]">
          {"© 2024 MeBox. All rights reserved."}
        </div>
      </footer>

      {/* FLOATING BUTTONS */}
      <div className="fixed bottom-4 right-4 flex flex-col gap-3 z-50">
        <a 
          href="tel:0373122528" 
          className="group relative"
        >
          <div className="absolute inset-0 bg-[#22c55e] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#22c55e] to-[#16a34a] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <Phone className="w-5 h-5 md:w-6 md:h-6" />
          </div>
          <div className="hidden md:block absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-[#22c55e] text-white px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
            Gọi ngay!
          </div>
        </a>
        <a 
          href="https://zalo.me/0373122528" 
          target="_blank" 
          rel="noopener noreferrer"
          className="group relative"
        >
          <div className="absolute inset-0 bg-[#0068ff] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#0068ff] to-[#0050cc] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <span className="font-black text-xs md:text-sm">Zalo</span>
          </div>
          <div className="hidden md:block absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-[#0068ff] text-white px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
            Chat Zalo ngay!
          </div>
        </a>
      </div>
    </div>
  )
}
