"use client"

import { useState } from "react"
import { Phone, Mail, MapPin, ArrowUp, Menu, X, Calendar, Users, Target, Heart } from "lucide-react"

export default function GioiThieuPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  return (
    <div className="font-sans text-foreground">
      {/* TOP BAR */}
      <div className="bg-gradient-to-r from-[#1a1a2e] via-[#1e3a5f] to-[#1a1a2e] text-white text-xs md:text-sm">
        {/* Mobile Layout */}
        <div className="flex md:hidden px-3 py-2.5 justify-between items-center">
          <a href="tel:0373122528" className="flex items-center gap-1.5 text-[#22c55e] font-semibold">
            <Phone className="w-3.5 h-3.5" /> 0373 122 528
          </a>
          <div className="flex items-center gap-3">
            <a href="/chinh-sach-ban-hang" className="text-[#ffd700] font-medium hover:text-white transition-colors">{"Chính sách"}</a>
            <a href="/gioi-thieu" className="text-[#22c55e] font-medium">{"Giới thiệu"}</a>
          </div>
        </div>
        {/* Desktop Layout */}
        <div className="hidden md:flex justify-between items-center px-4 lg:px-10 py-2.5">
          <div className="flex items-center gap-6 lg:gap-8">
            <a href="tel:0373122528" className="flex items-center gap-2 hover:text-[#22c55e] transition-colors group">
              <div className="w-7 h-7 bg-[#22c55e] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-semibold">0373 122 528 - 0865 108 823</span>
            </a>
          </div>
          <div className="flex items-center gap-1">
            <a href="/" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Trang chủ"}</a>
            <a href="/chinh-sach-ban-hang" className="px-3 py-1.5 rounded-full text-[#ffd700] font-semibold text-xs hover:bg-white/10 transition-colors">{"Chính sách bán hàng"}</a>
            <a href="/gioi-thieu" className="px-3 py-1.5 rounded-full bg-[#22c55e] text-white font-semibold text-xs hover:bg-[#16a34a] transition-colors">{"Giới thiệu"}</a>
            <a href="/san-pham" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Sản phẩm"}</a>
            <a href="/tin-tuc" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Tin tức"}</a>
            <a href="/lien-he" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Liên hệ"}</a>
          </div>
        </div>
      </div>

      {/* NAVBAR */}
      <nav className="bg-white border-t border-[#eee] border-b-[3px] border-b-[#22c55e] px-4 lg:px-10 flex items-center justify-between sticky top-0 z-50 shadow-sm">
        <a href="/" className="flex items-center gap-2 py-2">
          <img 
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E1%BA%A3nh%20logo-s6wIBI1jXip1zwNmoCzX4xHCxJCHHM.jpg" 
            alt="MeBox Logo" 
            className="w-10 h-10 md:w-12 md:h-12 rounded-full object-cover"
          />
          <span className="text-xl md:text-2xl font-black text-[#1a1a2e]">
            Me<span className="text-[#22c55e]">Box</span>
          </span>
        </a>
        
        {/* Desktop Menu */}
        <div className="hidden md:flex items-center">
          {[
            { name: "Trang chủ", href: "/" },
            { name: "Chính sách bán hàng", href: "/chinh-sach-ban-hang" },
            { name: "Sản phẩm", href: "/san-pham" },
            { name: "Giới thiệu", href: "/gioi-thieu" },
            { name: "Tin tức", href: "/tin-tuc" },
            { name: "Liên hệ", href: "/lien-he" }
          ].map((item, i) => (
            <a
              key={item.name}
              href={item.href}
              className={`px-3 lg:px-4 py-[18px] text-[12px] lg:text-[13.5px] font-semibold border-b-[3px] -mb-[3px] transition-colors ${
                i === 3 ? "text-[#22c55e] border-[#22c55e]" : "text-[#333] border-transparent hover:text-[#22c55e] hover:border-[#22c55e]"
              }`}
            >
              {item.name}
            </a>
          ))}
        </div>

        {/* Mobile Menu Button */}
        <button 
          className="md:hidden p-2"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
        >
          {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-[#eee] shadow-lg">
          {[
            { name: "Trang chủ", href: "/" },
            { name: "Chính sách bán hàng", href: "/chinh-sach-ban-hang" },
            { name: "Sản phẩm", href: "/san-pham" },
            { name: "Giới thiệu", href: "/gioi-thieu" },
            { name: "Tin tức", href: "/tin-tuc" },
            { name: "Liên hệ", href: "/lien-he" }
          ].map((item, i) => (
            <a
              key={item.name}
              href={item.href}
              onClick={() => setMobileMenuOpen(false)}
              className={`block px-4 py-3 text-sm font-semibold border-b border-[#f0f0f0] ${
                i === 3 ? "text-[#22c55e]" : "text-[#333]"
              }`}
            >
              {item.name}
            </a>
          ))}
        </div>
      )}

      {/* BANNER */}
      <section className="bg-gradient-to-r from-[#1a5276] to-[#2980b9] py-12 md:py-16 px-4 md:px-10 text-center">
        <h1 className="text-2xl md:text-4xl font-black text-white mb-4">{"VỀ MEBOX"}</h1>
        <p className="text-white/80 text-sm md:text-base max-w-2xl mx-auto">
          {"Nâng tầm thương hiệu Việt - Đồng hành cùng thương mại điện tử Việt Nam"}
        </p>
      </section>

      {/* CÂU CHUYỆN MEBOX */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8 md:mb-12">
            <h2 className="text-xl md:text-3xl font-black text-[#1a1a2e] mb-4">{"CÂU CHUYỆN MEBOX"}</h2>
            <div className="w-20 h-1 bg-[#22c55e] mx-auto"></div>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <Calendar className="w-6 h-6 text-[#22c55e]" />
                <span className="text-lg font-bold text-[#22c55e]">{"Thành lập ngày 06/01/2022"}</span>
              </div>
              <p className="text-[#555] leading-relaxed mb-4">
                {"Công ty MeBox được thành lập ngày 06/01/2022 với sứ mệnh nâng tầm thương hiệu Việt, đóng góp cho sự phát triển thương mại điện tử của Việt Nam."}
              </p>
              <p className="text-[#555] leading-relaxed mb-4">
                {"MeBox được sáng lập bởi 2 thành viên. Ban đầu đội ngũ nhân sự của MeBox chỉ có 4 người, với nguồn lực hạn chế, tài chính ít ỏi, máy móc thô sơ, đội ngũ của MeBox đã gặp rất nhiều khó khăn, phải kiêm nhiệm rất nhiều vị trí, rất nhiều gian nan và thử thách. Nhưng bằng sự quyết tâm đồng sức đồng lòng của các thành viên, MeBox dần dần phát triển và lớn mạnh hơn."}
              </p>
              <p className="text-[#555] leading-relaxed">
                {"MeBox luôn cam kết hoạt động với phương châm hết lòng phục vụ khách hàng, luôn luôn lắng nghe mọi nhu cầu của khách hàng, từ đó cải tiến, thay đổi để phục vụ khách hàng tốt hơn. Đội ngũ của MeBox luôn làm việc chăm chỉ ngày đêm để có thể mang lại những sản phẩm tốt nhất đến với khách hàng, cũng là niềm vui và sứ mệnh mà MeBox theo đuổi."}
              </p>
            </div>
            <div className="rounded-xl overflow-hidden shadow-lg">
              <img 
                src="https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=600&q=80" 
                alt="Kho hàng MeBox"
                className="w-full h-[300px] md:h-[400px] object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* ĐỘI NGŨ SÁNG LẬP */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-[#f9f9f9]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8 md:mb-12">
            <h2 className="text-xl md:text-3xl font-black text-[#1a1a2e] mb-4">{"ĐỘI NGŨ SÁNG LẬP"}</h2>
            <div className="w-20 h-1 bg-[#22c55e] mx-auto mb-4"></div>
            <p className="text-[#666] max-w-2xl mx-auto">{"Hai người sáng lập với tầm nhìn và sứ mệnh đưa MeBox phát triển"}</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 max-w-3xl mx-auto">
            {[
              { name: "Nhà sáng lập 1", role: "Co-Founder & CEO" },
              { name: "Nhà sáng lập 2", role: "Co-Founder & COO" }
            ].map((founder, index) => (
              <div key={index} className="bg-white rounded-xl shadow-lg overflow-hidden text-center">
                <div className="h-[250px] md:h-[300px] bg-gradient-to-br from-[#1a5276] to-[#2980b9] flex items-center justify-center">
                  <div className="w-32 h-32 md:w-40 md:h-40 rounded-full bg-white/20 flex items-center justify-center">
                    <Users className="w-16 h-16 md:w-20 md:h-20 text-white/80" />
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="text-lg md:text-xl font-bold text-[#1a1a2e] mb-1">{founder.name}</h3>
                  <p className="text-[#22c55e] font-semibold text-sm">{founder.role}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ĐỘI NGŨ NHÂN VIÊN */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8 md:mb-12">
            <h2 className="text-xl md:text-3xl font-black text-[#1a1a2e] mb-4">{"ĐỘI NGŨ NHÂN VIÊN"}</h2>
            <div className="w-20 h-1 bg-[#22c55e] mx-auto mb-4"></div>
            <p className="text-[#666] max-w-2xl mx-auto">{"Đội ngũ nhân viên tận tâm, chuyên nghiệp, luôn nỗ lực hết mình vì khách hàng"}</p>
          </div>
          
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4 md:gap-6">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((member) => (
              <div key={member} className="bg-[#f9f9f9] rounded-xl overflow-hidden shadow-md text-center">
                <div className="h-[120px] md:h-[150px] bg-gradient-to-br from-[#22c55e] to-[#16a34a] flex items-center justify-center">
                  <div className="w-16 h-16 md:w-20 md:h-20 rounded-full bg-white/20 flex items-center justify-center">
                    <Users className="w-8 h-8 md:w-10 md:h-10 text-white/80" />
                  </div>
                </div>
                <div className="p-3">
                  <h4 className="text-sm md:text-base font-bold text-[#1a1a2e]">{`Nhân viên ${member}`}</h4>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* GIÁ TRỊ CỐT LÕI */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-[#f9f9f9]">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8 md:mb-12">
            <h2 className="text-xl md:text-3xl font-black text-[#1a1a2e] mb-4">{"GIÁ TRỊ CỐT LÕI"}</h2>
            <div className="w-20 h-1 bg-[#22c55e] mx-auto"></div>
          </div>
          
          <div className="rounded-xl overflow-hidden shadow-lg">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/gi%C3%A1%20tr%E1%BB%8B%20c%E1%BB%91t%20l%C3%B5i-pkQZIoatCdyt1DHE0so1Hl6BpYN1xd.jpg" 
              alt="Giá trị cốt lõi MeBox"
              className="w-full h-auto object-contain"
            />
          </div>
        </div>
      </section>

      {/* VĂN HÓA DOANH NGHIỆP */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-8 md:mb-12">
            <h2 className="text-xl md:text-3xl font-black text-[#1a1a2e] mb-4">{"VĂN HÓA DOANH NGHIỆP"}</h2>
            <div className="w-20 h-1 bg-[#22c55e] mx-auto"></div>
          </div>
          
          <div className="rounded-xl overflow-hidden shadow-lg">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/v%C4%83n%20h%C3%B3a%20doanh%20nghi%E1%BB%87p-1wGD2l75FobK5og9l3Rl65ILOYLXxS.jpg" 
              alt="Văn hóa doanh nghiệp MeBox"
              className="w-full h-auto object-contain"
            />
          </div>
        </div>
      </section>

      {/* SỨ MỆNH */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-gradient-to-r from-[#1a5276] to-[#2980b9] text-white text-center">
        <div className="max-w-4xl mx-auto">
          <Target className="w-12 h-12 md:w-16 md:h-16 mx-auto mb-4 text-[#ffd700]" />
          <h2 className="text-xl md:text-3xl font-black mb-4">{"SỨ MỆNH CỦA MEBOX"}</h2>
          <p className="text-white/90 text-base md:text-lg leading-relaxed">
            {"\"Nâng tầm thương hiệu Việt, đóng góp cho sự phát triển thương mại điện tử của Việt Nam. Mang đến những sản phẩm bao bì chất lượng cao với giá cả hợp lý, phục vụ tận tâm cho mọi khách hàng từ doanh nghiệp lớn đến các shop online nhỏ.\""}
          </p>
        </div>
      </section>

      {/* THỐNG KÊ */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-white">
        <div className="max-w-5xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 md:gap-6">
            {[
              { number: "4+", label: "Năm kinh nghiệm" },
              { number: "500+", label: "Khách hàng tin tưởng" },
              { number: "100+", label: "Kích thước hộp" },
              { number: "5.000", label: "m² nhà xưởng", hasUnit: true }
            ].map((stat, index) => (
              <div key={index} className="bg-[#f9f9f9] rounded-xl p-5 md:p-6 text-center shadow-md">
                <div className="text-2xl md:text-4xl font-black text-[#22c55e] mb-2">
                  {stat.hasUnit ? (
                    <>{stat.number} <span className="text-base md:text-xl">{stat.label.split(" ")[0]}</span></>
                  ) : stat.number}
                </div>
                <div className="text-sm md:text-base text-[#666] font-medium">
                  {stat.hasUnit ? stat.label.split(" ").slice(1).join(" ") : stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-gradient-to-r from-[#22c55e] to-[#16a34a] text-white text-center">
        <div className="max-w-3xl mx-auto">
          <Heart className="w-10 h-10 md:w-12 md:h-12 mx-auto mb-4" />
          <h2 className="text-xl md:text-3xl font-black mb-4">{"LIÊN HỆ VỚI MEBOX NGAY"}</h2>
          <p className="text-white/90 mb-6">{"Hãy để MeBox đồng hành cùng bạn trong hành trình phát triển thương hiệu"}</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a 
              href="tel:0373122528"
              className="bg-white text-[#22c55e] px-6 py-3 rounded-full font-bold hover:bg-[#f0f0f0] transition-colors"
            >
              {"Gọi ngay: 0373 122 528"}
            </a>
            <a 
              href="https://zalo.me/0373122528"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#0068ff] text-white px-6 py-3 rounded-full font-bold hover:bg-[#0050cc] transition-colors"
            >
              {"Chat Zalo ngay"}
            </a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#1a1a2e] text-[#ccc] py-10 md:py-12 px-4 md:px-10">
        <div className="max-w-6xl mx-auto grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <img 
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E1%BA%A3nh%20logo-s6wIBI1jXip1zwNmoCzX4xHCxJCHHM.jpg" 
                alt="MeBox Logo" 
                className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover" 
              />
              <span className="text-lg font-black text-white">
                Me<span className="text-[#22c55e]">Box</span>
              </span>
            </div>
            <p className="text-[12px] md:text-[12.5px] leading-relaxed mb-4">
              {"MeBox - Chuyên cung cấp các giải pháp gia công bao bì chất lượng cao, phục vụ cho hàng trăm doanh nghiệp, hộ kinh doanh và các shop Online."}
            </p>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">{"Mục Lục"}</h5>
            <ul className="text-[11px] md:text-xs space-y-2">
              {["Giới thiệu", "Tin tức", "Tuyển dụng", "Liên hệ"].map((item) => (
                <li key={item}><a href="#" className="hover:text-white transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">{"Sản phẩm"}</h5>
            <ul className="text-[11px] md:text-xs space-y-2">
              {["Hộp Carton Giá Sỉ", "Hộp Carton Online", "Hộp Carton Giá Xưởng", "Hộp Đóng Gói"].map((item) => (
                <li key={item}><a href="#" className="hover:text-white transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">{"Liên hệ"}</h5>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <MapPin className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              <div>
                <p>{"Văn phòng: 125 đường số 5, KDC Vĩnh Lộc, Phường Bình Tân, TP. Hồ Chí Minh"}</p>
                <p className="mt-1">{"Nhà Máy: Lô A7, CCN Nhị Xuân, Xã Xuân Thới Sơn, TP. Hồ Chí Minh"}</p>
              </div>
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <Phone className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              0373 122 528 - 0865 108 823
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs">
              <Mail className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              salesmebox.vn@gmail.com
            </div>
          </div>
        </div>
        <div className="max-w-6xl mx-auto mt-8 pt-6 border-t border-[#333] text-center text-[11px] md:text-xs">
          <p>{"© 2022 - 2026 MeBox. Tất cả quyền được bảo lưu."}</p>
        </div>
      </footer>

      {/* FLOATING BUTTONS */}
      <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 flex flex-col gap-3 z-50">
        <a 
          href="https://zalo.me/0373122528" 
          target="_blank" 
          rel="noopener noreferrer"
          className="group relative"
        >
          <div className="absolute inset-0 bg-[#0068ff] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#0068ff] to-[#0050cc] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <span className="font-black text-xs md:text-sm">Zalo</span>
          </div>
          <div className="hidden md:block absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-[#0068ff] text-white px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
            {"Chat Zalo ngay!"}
          </div>
        </a>
        <a 
          href="tel:0373122528"
          className="group relative"
        >
          <div className="absolute inset-0 bg-[#22c55e] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#22c55e] to-[#16a34a] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <Phone className="w-5 h-5 md:w-6 md:h-6" />
          </div>
          <div className="hidden md:block absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-[#22c55e] text-white px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
            {"Gọi ngay!"}
          </div>
        </a>
        <button 
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="w-12 h-12 md:w-14 md:h-14 rounded-full bg-[#333] text-white flex items-center justify-center shadow-xl hover:bg-[#555] transition-colors"
        >
          <ArrowUp className="w-5 h-5 md:w-6 md:h-6" />
        </button>
      </div>
    </div>
  )
}
