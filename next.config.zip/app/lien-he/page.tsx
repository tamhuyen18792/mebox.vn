"use client"

import { useState } from "react"
import { Phone, Mail, MapPin, Clock, Menu, X, Factory, Building2, MessageCircle } from "lucide-react"

export default function LienHePage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const menuItems = [
    { name: "Trang chủ", href: "/" },
    { name: "Chính sách bán hàng", href: "/chinh-sach-ban-hang" },
    { name: "Sản phẩm", href: "/san-pham" },
    { name: "Giới thiệu", href: "/gioi-thieu" },
    { name: "Tin tức", href: "/tin-tuc" },
    { name: "Liên hệ", href: "/lien-he" },
  ]

  return (
    <div className="min-h-screen bg-[#f5f5f5]">
      {/* TOP BAR */}
      <div className="bg-gradient-to-r from-[#1a1a2e] via-[#1e3a5f] to-[#1a1a2e] text-white text-xs md:text-sm">
        {/* Mobile Layout */}
        <div className="flex md:hidden px-3 py-2.5 justify-between items-center">
          <a href="tel:0373122528" className="flex items-center gap-1.5 text-[#22c55e] font-semibold">
            <Phone className="w-3.5 h-3.5" /> 0373 122 528
          </a>
          <div className="flex items-center gap-3">
            <a href="/chinh-sach-ban-hang" className="text-[#ffd700] font-medium hover:text-white transition-colors">{"Chính sách"}</a>
            <a href="/lien-he" className="text-[#22c55e] font-medium">{"Liên hệ"}</a>
          </div>
        </div>
        {/* Desktop Layout */}
        <div className="hidden md:flex justify-between items-center px-4 lg:px-10 py-2.5">
          <div className="flex items-center gap-6 lg:gap-8">
            <a href="tel:0373122528" className="flex items-center gap-2 hover:text-[#22c55e] transition-colors group">
              <div className="w-7 h-7 bg-[#22c55e] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-semibold">0373 122 528 - 0865 108 823</span>
            </a>
          </div>
          <div className="flex items-center gap-1">
            <a href="/" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Trang chủ"}</a>
            <a href="/chinh-sach-ban-hang" className="px-3 py-1.5 rounded-full text-[#ffd700] font-semibold text-xs hover:bg-white/10 transition-colors">{"Chính sách bán hàng"}</a>
            <a href="/gioi-thieu" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Giới thiệu"}</a>
            <a href="/san-pham" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Sản phẩm"}</a>
            <a href="/tin-tuc" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Tin tức"}</a>
            <a href="/lien-he" className="px-3 py-1.5 rounded-full bg-[#22c55e] text-white font-semibold text-xs hover:bg-[#16a34a] transition-colors">{"Liên hệ"}</a>
          </div>
        </div>
      </div>

      {/* HEADER */}
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="flex justify-between items-center px-4 md:px-6 lg:px-10 py-3 border-b-[3px] border-[#22c55e]">
          <a href="/" className="flex items-center gap-2.5">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E1%BA%A3nh%20logo-s6wIBI1jXip1zwNmoCzX4xHCxJCHHM.jpg" 
              alt="MeBox Logo" 
              className="w-10 h-10 md:w-12 md:h-12 rounded-full object-cover shadow-md" 
            />
            <span className="text-xl md:text-2xl font-black text-[#1a1a2e]">
              Me<span className="text-[#22c55e]">Box</span>
            </span>
          </a>

          {/* Desktop Menu */}
          <nav className="hidden md:flex items-center">
            {menuItems.map((item, i) => (
              <a
                key={item.name}
                href={item.href}
                className={`px-3 lg:px-4 py-[18px] text-[12px] lg:text-[13.5px] font-semibold border-b-[3px] -mb-[3px] transition-colors ${
                  item.name === "Liên hệ" ? "text-[#22c55e] border-[#22c55e]" : "text-[#333] border-transparent hover:text-[#22c55e] hover:border-[#22c55e]"
                }`}
              >
                {item.name}
              </a>
            ))}
          </nav>

          {/* Mobile Menu Button */}
          <button 
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-t">
            {menuItems.map((item, i) => (
              <a
                key={item.name}
                href={item.href}
                onClick={() => setMobileMenuOpen(false)}
                className={`block px-4 py-3 text-sm font-semibold border-b border-[#f0f0f0] ${
                  item.name === "Liên hệ" ? "text-[#22c55e]" : "text-[#333]"
                }`}
              >
                {item.name}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* BANNER */}
      <section className="bg-gradient-to-r from-[#1e3a5f] to-[#2d5a87] text-white py-12 md:py-16">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <h1 className="text-3xl md:text-4xl lg:text-5xl font-black mb-4">Liên Hệ Với Chúng Tôi</h1>
          <p className="text-lg md:text-xl text-white/80 max-w-2xl mx-auto">
            MeBox luôn sẵn sàng lắng nghe và hỗ trợ bạn. Hãy liên hệ với chúng tôi để được tư vấn miễn phí!
          </p>
          <div className="flex items-center justify-center gap-2 mt-4 text-sm text-white/60">
            <a href="/" className="hover:text-white">Trang chủ</a>
            <span>/</span>
            <span className="text-[#22c55e]">Liên hệ</span>
          </div>
        </div>
      </section>

      {/* CONTACT INFO CARDS */}
      <section className="py-12 md:py-16 px-4">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {/* Văn phòng */}
            <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow text-center group">
              <div className="w-16 h-16 bg-gradient-to-br from-[#22c55e] to-[#16a34a] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Building2 className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-lg text-[#1a1a2e] mb-2">Văn Phòng</h3>
              <p className="text-[#666] text-sm leading-relaxed">
                125 đường số 5, KDC Vĩnh Lộc, Phường Bình Tân, TP. Hồ Chí Minh
              </p>
            </div>

            {/* Nhà máy */}
            <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow text-center group">
              <div className="w-16 h-16 bg-gradient-to-br from-[#3498db] to-[#2980b9] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Factory className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-lg text-[#1a1a2e] mb-2">Nhà Máy</h3>
              <p className="text-[#666] text-sm leading-relaxed">
                Lô A7, CCN Nhị Xuân, Xã Xuân Thới Sơn, Huyện Hóc Môn, TP. Hồ Chí Minh
              </p>
            </div>

            {/* Điện thoại */}
            <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow text-center group">
              <div className="w-16 h-16 bg-gradient-to-br from-[#e74c3c] to-[#c0392b] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Phone className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-lg text-[#1a1a2e] mb-2">Hotline</h3>
              <p className="text-[#666] text-sm">
                <a href="tel:0373122528" className="hover:text-[#22c55e] transition-colors block">0373 122 528</a>
                <a href="tel:0865108823" className="hover:text-[#22c55e] transition-colors block">0865 108 823</a>
              </p>
            </div>

            {/* Email */}
            <div className="bg-white rounded-xl p-6 shadow-lg hover:shadow-xl transition-shadow text-center group">
              <div className="w-16 h-16 bg-gradient-to-br from-[#9b59b6] to-[#8e44ad] rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <Mail className="w-8 h-8 text-white" />
              </div>
              <h3 className="font-bold text-lg text-[#1a1a2e] mb-2">Email</h3>
              <p className="text-[#666] text-sm">
                <a href="mailto:salesmebox.vn@gmail.com" className="hover:text-[#22c55e] transition-colors">
                  salesmebox.vn@gmail.com
                </a>
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* MAP SECTION */}
      <section className="py-12 md:py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-2xl md:text-3xl font-black text-[#1a1a2e] mb-3">Bản Đồ</h2>
            <p className="text-[#666] max-w-2xl mx-auto">
              Vị trí văn phòng MeBox tại TP. Hồ Chí Minh
            </p>
          </div>

          <div className="rounded-2xl overflow-hidden shadow-lg">
            <iframe
              src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3919.6696!2d106.5861!3d10.7591!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x31752c4e4c4e4c4e%3A0x4e4e4e4e4e4e4e4e!2zMTI1IMSRxrDhu51uZyBz4buRIDUsIEtEQyBWxKluaCBM4buZYywgQsOsbmggVMOibiwgVFAuIEjhu5MgQ2jDrSBNaW5o!5e0!3m2!1svi!2s!4v1234567890"
              width="100%"
              height="450"
              style={{ border: 0 }}
              allowFullScreen
              loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              title="MeBox Location"
            />
          </div>
        </div>
      </section>

      {/* WORKING HOURS */}
      <section className="py-12 md:py-16 px-4 bg-gradient-to-r from-[#1e3a5f] to-[#2d5a87]">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div className="text-white">
              <h2 className="text-2xl md:text-3xl font-black mb-4">Giờ Làm Việc</h2>
              <p className="text-white/80 mb-6">
                MeBox hoạt động 6 ngày trong tuần, luôn sẵn sàng phục vụ quý khách hàng
              </p>
              <div className="space-y-3">
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-[#22c55e]" />
                  <span><strong>Thứ 2 - Thứ 6:</strong> 8:00 - 18:00</span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-[#22c55e]" />
                  <span><strong>Thứ 7:</strong> 8:00 - 12:00</span>
                </div>
                <div className="flex items-center gap-3">
                  <Clock className="w-5 h-5 text-[#ffd700]" />
                  <span><strong>Chủ nhật:</strong> Nghỉ</span>
                </div>
              </div>
            </div>
            <div className="bg-white/10 backdrop-blur-sm rounded-2xl p-6 md:p-8">
              <h3 className="text-white font-bold text-xl mb-4">Liên Hệ Nhanh</h3>
              <div className="space-y-4">
                <a 
                  href="tel:0373122528" 
                  className="flex items-center gap-3 bg-[#22c55e] text-white px-5 py-3 rounded-lg font-semibold hover:bg-[#16a34a] transition-colors"
                >
                  <Phone className="w-5 h-5" />
                  Gọi ngay: 0373 122 528
                </a>
                <a 
                  href="https://zalo.me/0373122528" 
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-3 bg-[#0068ff] text-white px-5 py-3 rounded-lg font-semibold hover:bg-[#0050cc] transition-colors"
                >
                  <MessageCircle className="w-5 h-5" />
                  Chat Zalo
                </a>
                <a 
                  href="mailto:salesmebox.vn@gmail.com" 
                  className="flex items-center gap-3 bg-white/20 text-white px-5 py-3 rounded-lg font-semibold hover:bg-white/30 transition-colors"
                >
                  <Mail className="w-5 h-5" />
                  Gửi Email
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#1a1a2e] text-[#aaa] pt-12 pb-6 px-4 md:px-6 lg:px-10">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 mb-8">
            <div className="col-span-2 md:col-span-1">
              <div className="flex items-center gap-2.5 mb-4">
                <img 
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E1%BA%A3nh%20logo-s6wIBI1jXip1zwNmoCzX4xHCxJCHHM.jpg" 
                  alt="MeBox Logo" 
                  className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover" 
                />
                <span className="text-lg font-black text-white">
                  Me<span className="text-[#22c55e]">Box</span>
                </span>
              </div>
              <p className="text-[12px] md:text-[12.5px] leading-relaxed mb-4">
                Chuyên cung cấp hộp carton, bao bì giấy chất lượng cao với giá cả cạnh tranh nhất thị trường.
              </p>
            </div>
            <div>
              <h4 className="text-white font-bold mb-3 text-sm">Liên kết</h4>
              <ul className="space-y-2 text-[12px]">
                <li><a href="/" className="hover:text-[#22c55e]">Trang chủ</a></li>
                <li><a href="/gioi-thieu" className="hover:text-[#22c55e]">Giới thiệu</a></li>
                <li><a href="/san-pham" className="hover:text-[#22c55e]">Sản phẩm</a></li>
                <li><a href="/tin-tuc" className="hover:text-[#22c55e]">Tin tức</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-3 text-sm">Chính sách</h4>
              <ul className="space-y-2 text-[12px]">
                <li><a href="/chinh-sach-ban-hang" className="hover:text-[#22c55e]">Chính sách bán hàng</a></li>
                <li><a href="#" className="hover:text-[#22c55e]">Chính sách đổi trả</a></li>
                <li><a href="#" className="hover:text-[#22c55e]">Chính sách vận chuyển</a></li>
              </ul>
            </div>
            <div>
              <h4 className="text-white font-bold mb-3 text-sm">Liên hệ</h4>
              <ul className="space-y-2 text-[12px]">
                <li className="flex items-start gap-2">
                  <Phone className="w-3.5 h-3.5 mt-0.5 text-[#22c55e]" />
                  0373 122 528
                </li>
                <li className="flex items-start gap-2">
                  <Mail className="w-3.5 h-3.5 mt-0.5 text-[#22c55e]" />
                  salesmebox.vn@gmail.com
                </li>
                <li className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 mt-0.5 text-[#22c55e]" />
                  125 đường số 5, KDC Vĩnh Lộc, Bình Tân, TP.HCM
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-[#333] pt-6 text-center text-[11px]">
            <p>© 2024 MeBox. All rights reserved.</p>
          </div>
        </div>
      </footer>

      {/* FLOATING BUTTONS */}
      <div className="fixed bottom-4 right-4 md:bottom-6 md:right-6 flex flex-col gap-3 z-50">
        <a 
          href="tel:0373122528"
          className="group relative"
        >
          <div className="absolute inset-0 bg-[#22c55e] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#22c55e] to-[#16a34a] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <Phone className="w-5 h-5 md:w-6 md:h-6" />
          </div>
        </a>
        <a 
          href="https://zalo.me/0373122528" 
          target="_blank" 
          rel="noopener noreferrer"
          className="group relative"
        >
          <div className="absolute inset-0 bg-[#0068ff] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#0068ff] to-[#0050cc] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <span className="font-black text-xs md:text-sm">Zalo</span>
          </div>
        </a>
      </div>
    </div>
  )
}
