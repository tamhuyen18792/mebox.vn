"use client"

import { useState, useEffect } from "react"
import { Check, Phone, Mail, MapPin, MessageCircle, ArrowUp, Search, ShoppingCart, Shield, Bookmark, MessageSquare, Package, ChevronLeft, ChevronRight, Menu, X } from "lucide-react"

export default function MeBoxPage() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  
  const bannerImages = [
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/trum%20carton%20h%C3%A0ng%20x%E1%BB%8Bn%20gi%C3%A1%20r%E1%BA%BB-Vn9NAoPa7NmspxoJBBbgN7TXtGUjiD.png",
      alt: "MeBox - Trùm Carton - Hàng xịn, giá rẻ, giao ngay - Chỉ từ 1K"
    },
    {
      src: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/BANNER%20TRANG%202-ejFz6keA09ArBLuHjPLUiHGOyPOcRo.jpg",
      alt: "MeBox - Đặt sản xuất thùng hộp carton - Giao nhanh trong 1-2 ngày"
    }
  ]

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % bannerImages.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [bannerImages.length])

  const goToSlide = (index: number) => setCurrentSlide(index)
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + bannerImages.length) % bannerImages.length)
  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % bannerImages.length)

  return (
    <div className="font-sans text-foreground">
      {/* TOP BAR - Visible on all devices */}
      <div className="bg-gradient-to-r from-[#1a1a2e] via-[#1e3a5f] to-[#1a1a2e] text-white text-xs md:text-sm">
        {/* Mobile Layout */}
        <div className="flex md:hidden px-3 py-2.5 justify-between items-center">
          <a href="tel:0373122528" className="flex items-center gap-1.5 text-[#22c55e] font-semibold">
            <Phone className="w-3.5 h-3.5" /> 0373 122 528
          </a>
          <div className="flex items-center gap-3">
            <a href="/chinh-sach-ban-hang" className="text-[#ffd700] font-medium hover:text-white transition-colors">{"Chính sách"}</a>
            <a href="/gioi-thieu" className="text-white/80 hover:text-white transition-colors">{"Giới thiệu"}</a>
          </div>
        </div>
        {/* Desktop Layout */}
        <div className="hidden md:flex justify-between items-center px-4 lg:px-10 py-2.5">
          <div className="flex items-center gap-6 lg:gap-8">
            <a href="tel:0373122528" className="flex items-center gap-2 hover:text-[#22c55e] transition-colors group">
              <div className="w-7 h-7 bg-[#22c55e] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-semibold">0373 122 528 - 0865 108 823</span>
            </a>
          </div>
          <div className="flex items-center gap-1">
            <a href="/" className="px-3 py-1.5 rounded-full bg-[#22c55e] text-white font-semibold text-xs hover:bg-[#16a34a] transition-colors">{"Trang chủ"}</a>
            <a href="/chinh-sach-ban-hang" className="px-3 py-1.5 rounded-full text-[#ffd700] font-semibold text-xs hover:bg-white/10 transition-colors">{"Chính sách bán hàng"}</a>
            <a href="/gioi-thieu" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Giới thiệu"}</a>
            <a href="/san-pham" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Sản phẩm"}</a>
            <a href="/tin-tuc" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Tin tức"}</a>
            <a href="/lien-he" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Liên hệ"}</a>
          </div>
        </div>
      </div>

      {/* HERO BANNER SLIDER */}
      <section className="relative w-full overflow-hidden group bg-[#1a1a2e]">
        {/* Slides */}
        <div 
          className="flex transition-transform duration-700 ease-in-out"
          style={{ transform: `translateX(-${currentSlide * 100}%)` }}
        >
          {bannerImages.map((image, index) => (
            <div key={index} className="w-full flex-shrink-0">
              <img
                src={image.src}
                alt={image.alt}
                className="w-full h-auto"
              />
            </div>
          ))}
        </div>
        
        {/* Navigation Arrows - Hidden on mobile */}
        <button 
          onClick={prevSlide}
          className="hidden md:flex absolute left-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/40 hover:bg-black/60 text-white rounded-full items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <button 
          onClick={nextSlide}
          className="hidden md:flex absolute right-4 top-1/2 -translate-y-1/2 w-10 h-10 bg-black/40 hover:bg-black/60 text-white rounded-full items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
        >
          <ChevronRight className="w-6 h-6" />
        </button>
        
        {/* Dots Indicator */}
        <div className="absolute bottom-2 md:bottom-4 left-1/2 -translate-x-1/2 flex gap-2">
          {bannerImages.map((_, index) => (
            <button
              key={index}
              onClick={() => goToSlide(index)}
              className={`w-2 h-2 md:w-3 md:h-3 rounded-full transition-all ${
                currentSlide === index 
                  ? "bg-[#22c55e] w-6 md:w-8" 
                  : "bg-white/70 hover:bg-white"
              }`}
            />
          ))}
        </div>
      </section>

      {/* NAVBAR */}
      <nav className="bg-white border-t border-[#eee] border-b-[3px] border-b-[#22c55e] px-4 lg:px-10 flex items-center justify-between sticky top-0 z-50 shadow-sm">
        <div className="flex items-center gap-2 py-2">
          <img 
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E1%BA%A3nh%20logo-s6wIBI1jXip1zwNmoCzX4xHCxJCHHM.jpg" 
            alt="MeBox Logo" 
            className="w-10 h-10 md:w-12 md:h-12 rounded-full object-cover"
          />
          <span className="text-base md:text-lg font-black text-[#222]">
            Me<span className="text-[#22c55e]">Box</span>
          </span>
        </div>
        
        {/* Desktop Menu */}
        <div className="hidden md:flex">
          {["Trang chủ", "Chính sách bán hàng", "Sản phẩm", "Giới thiệu", "Tin tức", "Liên hệ"].map((item, i) => (
            <a
              key={item}
              href={item === "Chính sách bán hàng" ? "/chinh-sach-ban-hang" : item === "Giới thiệu" ? "/gioi-thieu" : item === "Sản phẩm" ? "/san-pham" : item === "Tin tức" ? "/tin-tuc" : item === "Liên hệ" ? "/lien-he" : item === "Trang chủ" ? "/" : "#"}
              className={`px-3 lg:px-4 py-[18px] text-[12px] lg:text-[13.5px] font-semibold border-b-[3px] -mb-[3px] transition-colors ${
                i === 0 ? "text-[#22c55e] border-[#22c55e]" : "text-[#333] border-transparent hover:text-[#22c55e] hover:border-[#22c55e]"
              }`}
            >
              {item}
            </a>
          ))}
        </div>
        
        <div className="flex gap-3 md:gap-4 items-center">
          <Search className="w-5 h-5 text-[#555] cursor-pointer" />
          <ShoppingCart className="w-5 h-5 text-[#555] cursor-pointer" />
          {/* Mobile Menu Button */}
          <button 
            className="md:hidden p-1"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </nav>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-white border-b border-[#eee] shadow-lg">
          {["Trang chủ", "Chính sách bán hàng", "Sản phẩm", "Giới thiệu", "Tin tức", "Liên hệ"].map((item, i) => (
            <a
              key={item}
              href={item === "Chính sách bán hàng" ? "/chinh-sach-ban-hang" : item === "Giới thiệu" ? "/gioi-thieu" : item === "Sản phẩm" ? "/san-pham" : item === "Tin tức" ? "/tin-tuc" : item === "Liên hệ" ? "/lien-he" : item === "Trang chủ" ? "/" : "#"}
              onClick={() => setMobileMenuOpen(false)}
              className={`block px-4 py-3 text-sm font-semibold border-b border-[#f0f0f0] ${
                i === 0 ? "text-[#22c55e]" : "text-[#333]"
              }`}
            >
              {item}
            </a>
          ))}
          <div className="px-4 py-3 flex flex-col gap-1 text-xs text-[#666]">
            <span className="flex items-center gap-1">
              <Phone className="w-3 h-3" /> 0373 122 528 - 0865 108 823
            </span>
            <span className="flex items-center gap-1">
              <Mail className="w-3 h-3" /> salesmebox.vn@gmail.com
            </span>
          </div>
        </div>
      )}

      {/* CATEGORIES - SẢN PHẨM VÀ DỊCH VỤ */}
      <section className="py-8 md:py-12 px-4 md:px-10 bg-[#1a5276]">
        <div className="text-center mb-6 md:mb-8">
          <h2 className="text-lg md:text-2xl font-black uppercase text-[#ffd700]">SẢN PHẨM VÀ DỊCH VỤ CỦA MEBOX</h2>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 md:gap-5">
          {[
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/unnamed%20%281%29-jrhUWqRZCeStEi6uZjZOgm9V7uTgVo.png", title: "Hộp carton có sẵn số lượng lớn", desc: "Đa dạng kích thước, giao hàng nhanh trong ngày tại TP.HCM và các tỉnh lân cận." },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/unnamed-ltIsAvy3hAuY0OPQBPklGuZaxwlDL1.jpg", title: "Miễn phí in theo yêu cầu với đơn từ 5 triệu", desc: "In logo, thông tin thương hiệu lên hộp carton theo yêu cầu của khách hàng." },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/unnamed-s0ywyHbsIaLE9ezXOu7YlRZXFnzynL.png", title: "Nhận đặt sản xuất hộp theo yêu cầu", desc: "Thiết kế và sản xuất hộp carton theo kích thước, chất liệu yêu cầu của khách hàng." },
          ].map((cat) => (
            <div key={cat.title} className="bg-[#1a5276] rounded-lg overflow-hidden shadow-md border border-[#2980b9]">
              <div className="relative h-48 md:h-60 cursor-pointer group">
                <img src={cat.img} alt={cat.title} className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" />
                <div className="absolute inset-0 bg-gradient-to-t from-black/65 to-transparent" />
                <div className="absolute bottom-4 left-4 right-4 md:bottom-5 md:left-5 md:right-5">
                  <h3 className="text-white text-base md:text-lg font-black">{cat.title}</h3>
                </div>
              </div>
              <div className="p-4">
                <p className="text-sm text-white leading-relaxed">{cat.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* FEATURES */}
      <section className="relative bg-[#eef4f4] py-10 md:py-13 px-4 md:px-10 overflow-hidden">
        <div
          className="absolute inset-0 opacity-[0.07]"
          style={{
            backgroundImage:
              "url('https://images.unsplash.com/photo-1604762524889-3e2fcc145683?w=1400&q=30')",
            backgroundSize: "cover",
            backgroundPosition: "left center",
          }}
        />
        <div className="relative z-10">
          <div className="flex justify-center mb-6">
            <h2 className="text-xl md:text-2xl font-black text-[#111] uppercase tracking-wide">
              TẠI SAO LẠI CHỌN <span className="text-[#22c55e]">CHÚNG TÔI</span>
            </h2>
          </div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
          {[
            { icon: Shield, title: "Giá sỉ tận xưởng", desc: "Trực tiếp từ xưởng sản xuất, không qua trung gian, giá t���t nhất thị trường" },
            { icon: Bookmark, title: "Sản lượng lớn", desc: "Đáp ứng mọi đơn hàng gấp, số lượng khủng" },
            { icon: MessageSquare, title: "Dịch vụ tận tâm", desc: "Giao hàng nhanh, Bốc xếp tận kho" },
            { icon: Package, title: "In miễn phí", desc: "Miễn phí in cho đơn hàng từ 5 triệu" },
          ].map((item) => (
            <div key={item.title} className="bg-[#1a5276] rounded-xl px-4 md:px-5 py-5 md:py-7 text-center shadow-md hover:-translate-y-1 hover:shadow-lg transition-all">
              <div className="hidden md:flex items-center gap-2 mb-5">
                <img 
                  src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E1%BA%A3nh%20logo-WEoBeXVNkFv5xjY6L37sGjynFaPvVd.jpg" 
                  alt="MeBox Logo" 
                  className="w-6 h-6 rounded-full object-cover"
                />
                <span className="text-[11.5px] font-bold text-[#ffd700]">Mebox</span>
              </div>
              <div className="w-14 h-14 md:w-18 md:h-18 mx-auto mb-3 md:mb-4 flex items-center justify-center">
                <item.icon className="w-10 h-10 md:w-14 md:h-14 text-[#ffd700] stroke-[1.3]" />
              </div>
              <h4 className="text-base md:text-lg font-extrabold text-[#ffd700] mb-2">{item.title}</h4>
              <p className="text-[12px] md:text-[14px] text-white leading-relaxed">{item.desc}</p>
            </div>
          ))}
          </div>
        </div>
      </section>

      {/* FACTORY HIGHLIGHT */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-gradient-to-r from-[#1a1a2e] to-[#2d1b3d] text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-20" style={{
          backgroundImage: "url('https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=1400&q=60')",
          backgroundSize: "cover",
          backgroundPosition: "center"
        }} />
        <div className="relative z-10 max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center">
            <div>
              <h2 className="text-xl md:text-3xl font-black uppercase mb-4 md:mb-6 leading-tight">
                NĂNG LỰC SẢN XUẤT <br/>
                <span className="text-[#22c55e]">6 TRIỆU HỘP / THÁNG</span>
              </h2>
              <p className="text-[#ccc] text-[13px] md:text-sm leading-relaxed mb-5 md:mb-6">
                MeBox tự hào sở hữu hệ thống xưởng sản xuất hiện đại với công suất lên đến 6 triệu hộp/tháng. 
                Với đội ngũ 60+ công nhân lành nghề và máy móc hiện đại, tự động hóa cao, chúng tôi cam kết 
                đáp ứng mọi đơn hàng với chất lượng cao nhất và thời gian nhanh nhất.
              </p>
              <div className="grid grid-cols-3 gap-3 md:gap-6 mb-6 md:mb-8">
                <div className="text-center">
                  <div className="text-xl md:text-3xl font-black text-[#22c55e] mb-1">6 Triệu</div>
                  <div className="text-xs md:text-sm text-[#aaa]">Hộp / tháng</div>
                </div>
                <div className="text-center">
                  <div className="text-xl md:text-3xl font-black text-[#22c55e] mb-1">60+</div>
                  <div className="text-xs md:text-sm text-[#aaa]">Công nhân</div>
                </div>
                <div className="text-center">
                  <div className="text-xl md:text-3xl font-black text-[#22c55e] mb-1">5.000 <span className="text-sm md:text-lg">m²</span></div>
                  <div className="text-xs md:text-sm text-[#aaa]">Diện tích xưởng</div>
                </div>
              </div>
            </div>
            <div className="rounded-lg overflow-hidden h-64 md:h-96 bg-black">
              <iframe
                src="https://www.youtube.com/embed/aCX_z_tNgp0"
                title="Video giới thiệu nhà máy MeBox"
                allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                allowFullScreen
                className="w-full h-full"
              />
            </div>
          </div>
        </div>
      </section>

      {/* WHOLESALE PRICING */}
      <section id="wholesale-pricing" className="py-10 md:py-16 px-4 md:px-10 bg-gradient-to-br from-[#f0fdf4] to-white">
        <div className="max-w-[1400px] mx-auto mb-3 md:mb-4">
          <div className="bg-[#1a5276] rounded-t-xl px-6 md:px-10 py-6 md:py-8 text-center shadow-lg">
            <h2 className="text-xl md:text-2xl font-black uppercase text-[#ffd700]">
              BẢNG GIÁ KHÁCH SỈ
            </h2>
            <p className="text-white text-sm md:text-base mt-3 font-medium">Ưu đãi đặc biệt dành cho đối tác và khách hàng mua số lượng lớn</p>
            <p className="text-[#ffd700] text-xs md:text-sm mt-2 font-semibold">(Giá đã bao gồm VAT)</p>
          </div>
        </div>
        <div className="max-w-[1400px] mx-auto">
          <img 
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/b%E1%BA%A3ng%20b%C3%A1o%20gi%C3%A1%20th%C3%A1ng%204.2026-zbaGb9VQAKcNCIZIONULBM3kQK8nqd.jpg"
            alt="Bảng báo giá hộp carton MeBox tháng 4/2026"
            className="w-full h-auto rounded-lg shadow-lg"
          />
        </div>

        {/* Additional Info */}
        <div className="mt-8 md:mt-10 text-center">
          <p className="text-[13px] md:text-sm text-[#666] mb-4">
            Bạn cần đơn hàng lớn hơn hoặc có yêu cầu đặc biệt?{" "}
            <a href="#" className="text-[#22c55e] font-semibold hover:underline">
              Liên hệ với chúng tôi
            </a>
          </p>
          <div className="inline-flex flex-col sm:flex-row items-center gap-3 md:gap-6 bg-white px-4 md:px-6 py-3 md:py-4 rounded-lg shadow">
            <div className="flex items-center gap-2">
              <Phone className="w-5 h-5 text-[#22c55e]" />
              <span className="font-bold text-[#333] text-sm md:text-base">0373 122 528 - 0865 108 823</span>
            </div>
            <div className="flex items-center gap-2">
              <Mail className="w-5 h-5 text-[#22c55e]" />
              <span className="font-bold text-[#333] text-sm md:text-base">sales@mebox.vn</span>
            </div>
          </div>
        </div>

        {/* QUY TRÌNH MUA HÀNG */}
        <div className="max-w-[1400px] mx-auto mt-6 md:mt-8">
          <img 
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/QUY%20TRINH%20MUA%20H%C3%80NG-pKRynr2V0YIEnl3sM3bTEioT3VlJ6l.jpg"
            alt="Quy trình mua hàng MeBox: Tư vấn - Báo giá - Xác nhận - Sản xuất - Giao hàng - Thanh toán"
            className="w-full h-auto rounded-lg shadow-lg"
          />
        </div>
      </section>

      {/* BRANDS */}
      <section className="py-8 md:py-12 px-4 md:px-10 bg-white">
        <h2 className="text-center text-base md:text-xl font-black uppercase mb-6 md:mb-8 tracking-wide">
          CÁC THƯƠNG HIỆU CHÚNG TÔI <span className="text-[#22c55e]">PHÂN PHỐI</span>
        </h2>
        <div className="flex justify-center items-center gap-3 md:gap-8 flex-wrap">
          {/* XIAOMEI Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697957895_6cce81ea0d768b7351fbab31981bb762-0ox6mU0w2Hc44fqf0CRzaDFUANv2JO.jpg" 
              alt="XIAOMEI Tomorrow Eyelashes" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* Sport Beauty Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697968823_3d1446be86334b1a0156c3681cc260fa-i3KnZjIdR67FxK0gSbp8NwK87MurMB.jpg" 
              alt="Sport Beauty" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* Ngoc Tran Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697972995_089e533175e0cffecbe987b6c3bbd626-UMZm6lyiM1z7wqe9PDWTwcJyPCxMiY.jpg" 
              alt="Ngoc Tran - Chuyen Phu Kien Nail" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* CUB_Shop Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697982900_cf64ce5d64eb86fb8080f35358940725-yfQpk7aD97oHSYDQSwIFAPIRdZqVkf.jpg" 
              alt="CUB_Shop - Phụ kiện Handmade" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* Shop Aussie Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700698006586_4f2acfe94035201b275a6493d1b1d55a-Uwpj6SUXMPCUZnpaRxMXaYVEy9NgEH.jpg" 
              alt="Shop Aussie - Bàn Chải Điện & Phụ Kiện" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* Minz Store Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697992158_2106432f0fb3085b6fc9d6ff8b1e7cdc-6tjrzOYdveSarUTmDmX9PFAz3MZGWB.jpg" 
              alt="Minz Store" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* HP Lube Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700698066756_8ddaa11922c5029f9c7e9ac872416cbd-fkUSTHb1R9cihXonmM7NIER6gWv00V.jpg" 
              alt="HP Lube - Best Choice" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* Chi Food Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700698041830_a934409a7698d5b4d61193d64d08a954-gcDz5wdEFIbz3p1a0tS4rkUTyFQJiz.jpg" 
              alt="Chi Food" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* LeeLong Cafe Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697986474_d4818e90aac77aff7b1421d6b06e37f5-sbIVsfqrivHXrhgeHBYrwOtQ4JGJBR.jpg" 
              alt="LeeLong - Cafe 7 Vi" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* Vanly Store Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700698006289_9bf1dbe24cbb7904e7463c94fe26e170-tqCKOyDR0CEfLcXncX13bt6JXYZV99.jpg" 
              alt="Vanly Store - Accessories & Gifts" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* Oanh Oanh Beauty Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697956487_f21c2c9052bf9130a294c273735669a0-vKXkerjm99BAewzDc3KNdtIFjK0Q57.jpg" 
              alt="Oanh Oanh Beauty - My Pham Nuoc Hoa" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
          {/* Goc An Vat Nha Soi Logo */}
          <div className="px-2 md:px-4 py-1 md:py-2 border border-[#e8e8e8] rounded min-w-[70px] md:min-w-[100px] hover:border-[#22c55e] transition-colors">
            <img 
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700698043044_b1f815e5d1e265fee6afc40f06cf9c03-peHceLrlQKyMilhJ95aSXrjbIqAL9O.jpg" 
              alt="Goc An Vat Nha Soi" 
              className="h-16 md:h-24 w-auto object-contain"
            />
          </div>
        </div>
      </section>

      {/* PRODUCTS */}
      <section className="py-8 md:py-12 px-4 md:px-10 bg-white">
        <div className="flex justify-between items-center mb-5 md:mb-7">
          <h2 className="text-base md:text-xl font-black flex items-center gap-2">
            <span className="text-[#22c55e]">✦</span> SẢN PHẨM NỔI BẬT
          </h2>
          <a href="#" className="text-[11px] md:text-xs text-[#22c55e]">
            Xem tất cả &rsaquo;
          </a>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 md:gap-5">
          {[
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/12x8x8-qcjGRbehfunuZiuwsFSasxW4edpiah.jpg", badge: "Hot", badgeType: "new", name: "Hộp carton 12x8x8", price: "866đ", oldPrice: "1,000đ" },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20x8x8-GOv82qz3mO5Y5iKsSC4HO8e8HGKCyl.jpg", badge: "Hot", badgeType: "sale", name: "Hộp carton 20x8x8", price: "1,097đ", oldPrice: "1,300đ", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/18x10x8-IfekhixMO8TNFf0YRF1WtGZvnDkx37.jpg", badge: "Hot", badgeType: "sale", name: "Hộp carton 18x10x8", price: "1,097đ", oldPrice: "1,300đ" },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20x10x10-wE1PYEMJFlU6ZVcwKQQ41qb1ddxFid.jpg", badge: "Hot", badgeType: "new", name: "Hộp carton 20x10x10", price: "1,271đ", oldPrice: "1,500đ", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/15x12x10-TfEoXEdlFnGyBByEWyah5R8DoMVGWE.jpg", badge: "Hot", badgeType: "sale", name: "H���p carton 15x12x10", price: "1,232đ", oldPrice: "1,450đ" },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/15x8x8-eCaQKN5kH6Lne9zpqkf8otSE2AOm9E.jpg", badge: "Hot", badgeType: "sale", name: "Hộp carton 15x8x8", price: "924đ", oldPrice: "1,100đ", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20x15x10-2pearBXd6hsraOHRrTJmCQZHUyRIZ4.jpg", badge: "Hot", badgeType: "new", name: "Hộp carton 20x15x10", price: "1,766đ", oldPrice: "2,000đ" },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/10x10x8-cEggGYK0mb4PpO0JnOQ9DBalFWMA5e.jpg", badge: "Hot", badgeType: "sale", name: "Hộp carton 10x10x8", price: "982đ", oldPrice: "1,150đ" },
          ].map((product, i) => (
            <div key={i} className="border border-[#f0f0f0] rounded-lg overflow-hidden hover:shadow-lg hover:-translate-y-0.5 transition-all">
              <div className="relative h-[140px] md:h-[180px] bg-[#f8f8f8] overflow-hidden">
                <img src={product.img} alt={product.name} className="w-full h-full object-cover" />
                <span className={`absolute top-2 left-2 md:top-2.5 md:left-2.5 text-[9px] md:text-[10px] font-bold px-1.5 md:px-2 py-0.5 rounded-sm text-white bg-[#22c55e]`}>
                  {product.badge}
                </span>
              </div>
              <div className="p-2.5 md:p-3.5">
                <div className="text-[#f39c12] text-[10px] md:text-xs mb-1">{"★".repeat(product.stars || 5)}{"☆".repeat(5 - (product.stars || 5))}</div>
                <h4 className="text-[11px] md:text-[13px] font-semibold mb-1.5 md:mb-2 leading-snug text-[#333] line-clamp-2">{product.name}</h4>
                <span className="text-[13px] md:text-[15px] font-bold text-[#22c55e]">{product.price}</span>
                {product.oldPrice && <span className="text-[10px] md:text-xs text-[#aaa] line-through ml-1">{product.oldPrice}</span>}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="py-10 md:py-14 px-4 md:px-10 bg-gradient-to-b from-[#f9f9f9] to-white text-center">
        <h2 className="text-lg md:text-[22px] font-black uppercase mb-6 md:mb-9">
          <span className="text-[#22c55e]">✦</span> ĐÁNH GIÁ TỪ KHÁCH HÀNG <span className="text-[#22c55e]">✦</span>
        </h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4 md:gap-6 max-w-5xl mx-auto">
          {[
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697957895_6cce81ea0d768b7351fbab31981bb762-0ox6mU0w2Hc44fqf0CRzaDFUANv2JO.jpg", name: "XIAOMEI Tomorrow Eyelashes", text: "San pham bao bi rat dep, chat luong vuot troi so voi muc gia. Giao hang nhanh, dong goi can than. Se tiep tuc ung ho MeBox.", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697968823_3d1446be86334b1a0156c3681cc260fa-i3KnZjIdR67FxK0gSbp8NwK87MurMB.jpg", name: "Sport Beauty", text: "Doi ngu tu van nhiet tinh, chuyen nghiep. San pham dung nhu mo ta, rat hai long voi dich vu cua MeBox.", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697972995_089e533175e0cffecbe987b6c3bbd626-UMZm6lyiM1z7wqe9PDWTwcJyPCxMiY.jpg", name: "Ngoc Tran - Phu Kien Nail", text: "Chat luong san pham on dinh, gia ca hop ly. Dich vu hau mai tot. Toi da dat hang nhieu lan va luon hai long.", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697982900_cf64ce5d64eb86fb8080f35358940725-yfQpk7aD97oHSYDQSwIFAPIRdZqVkf.jpg", name: "CUB_Shop - Phu kien Handmade", text: "MeBox la doi tac dang tin cay. Hop carton chat luong tot, gia ca canh tranh. Rat phu hop cho shop online nhu minh.", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700698006586_4f2acfe94035201b275a6493d1b1d55a-Uwpj6SUXMPCUZnpaRxMXaYVEy9NgEH.jpg", name: "Shop Aussie - Ban Chai Dien", text: "Da su dung dich vu cua MeBox hon 2 nam. Luon hai long voi chat luong va thai do phuc vu chuyen nghiep.", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697992158_2106432f0fb3085b6fc9d6ff8b1e7cdc-6tjrzOYdveSarUTmDmX9PFAz3MZGWB.jpg", name: "Minz Store", text: "Gia si tot nhat thi truong. Giao hang dung hen, ho tro nhiet tinh. Cam on MeBox da dong hanh cung shop minh.", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700698066756_8ddaa11922c5029f9c7e9ac872416cbd-fkUSTHb1R9cihXonmM7NIER6gWv00V.jpg", name: "HP Lube - Best Choice", text: "Hop carton chat luong cao, in an dep. Khach hang cua minh rat thich bao bi tu MeBox. Se gioi thieu cho ban be.", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700698041830_a934409a7698d5b4d61193d64d08a954-gcDz5wdEFIbz3p1a0tS4rkUTyFQJiz.jpg", name: "Chi Food", text: "Dich vu tu van tan tam, giai dap moi thac mac. San pham giao dung mau, dung kich thuoc. 10 diem cho MeBox!", stars: 5 },
            { img: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/z7700697986474_d4818e90aac77aff7b1421d6b06e37f5-sbIVsfqrivHXrhgeHBYrwOtQ4JGJBR.jpg", name: "LeeLong - Cafe 7 Vi", text: "Shop minh chuyen do uong, can hop dep de dong goi. MeBox dap ung tot yeu cau, gia hop ly. Rat hai long!", stars: 5 },
          ].map((t) => (
            <div key={t.name} className="bg-white rounded-xl px-4 md:px-5 py-5 md:py-7 shadow-md text-left">
              <img 
                src={t.img} 
                alt={t.name}
                className="w-14 h-14 md:w-16 md:h-16 rounded-full object-cover mb-3 border-2 border-[#22c55e] shadow-md"
              />
              <div className="text-[#f39c12] text-[12px] md:text-[13px] mb-2">{"★".repeat(t.stars || 5)}{"☆".repeat(5 - (t.stars || 5))}</div>
              <p className="text-[12px] md:text-[13px] text-[#666] leading-relaxed italic mb-2 md:mb-3">&ldquo;{t.text}&rdquo;</p>
              <span className="text-[12px] md:text-[13px] font-bold text-[#333]">{t.name}</span>
            </div>
          ))}
        </div>
      </section>

      {/* NEWSLETTER */}
      <section className="py-10 md:py-14 px-4 md:px-10 text-center bg-gradient-to-br from-[#f0fdf4] to-white">
        <h2 className="text-lg md:text-[22px] font-black uppercase mb-2">
          <span className="text-[#22c55e]">✦</span> ĐĂNG KÝ NHẬN THÔNG TIN <span className="text-[#22c55e]">✦</span>
        </h2>
        <p className="text-[12px] md:text-[13px] text-[#777] mb-5 md:mb-6">Nhận ngay những thông tin mới nhất về sản phẩm, khuyến mãi và tin tức từ MeBox</p>
        <div className="flex flex-col sm:flex-row justify-center max-w-[480px] mx-auto gap-2 sm:gap-0">
          <input
            type="email"
            placeholder="Địa chỉ email của bạn..."
            className="flex-1 px-4 py-2.5 md:py-3 border-[1.5px] border-[#ddd] sm:border-r-0 rounded sm:rounded-l sm:rounded-r-none text-[13px] outline-none focus:border-[#22c55e]"
          />
          <button className="bg-[#22c55e] hover:bg-[#16a34a] text-white px-6 py-2.5 md:py-3 rounded sm:rounded-l-none sm:rounded-r font-bold text-[13px] transition-colors">
            Đăng ký
          </button>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#1a1a2e] text-[#ccc] pt-10 md:pt-12 px-4 md:px-10 pb-6">
        <div className="grid grid-cols-2 md:grid-cols-[1.5fr_1fr_1fr_1fr] gap-6 md:gap-10 mb-8 md:mb-9">
          <div className="col-span-2 md:col-span-1">
            <div className="flex items-center gap-2.5 mb-4">
              <img 
                src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/%E1%BA%A3nh%20logo-s6wIBI1jXip1zwNmoCzX4xHCxJCHHM.jpg" 
                alt="MeBox Logo" 
                className="w-8 h-8 md:w-10 md:h-10 rounded-full object-cover" 
              />
              <span className="text-lg font-black text-white">
                Me<span className="text-[#22c55e]">Box</span>
              </span>
            </div>
            <p className="text-[12px] md:text-[12.5px] leading-relaxed mb-4">
              {"MeBox - Chuyên cung cấp các giải pháp gia công bao bì chất lượng cao, phục vụ cho hàng trăm doanh nghiệp, hộ kinh doanh và các shop Online."}
            </p>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">Mục Lục</h5>
            <ul className="space-y-2">
              {["Giới thiệu", "Tin tức", "Tuyển dụng", "Liên hệ"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-[11px] md:text-[12.5px] text-[#bbb] hover:text-[#22c55e] transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">Sản phẩm</h5>
            <ul className="space-y-2">
              {["Hộp Carton Giá Sỉ", "Hộp Carton Online", "Hộp Carton Giá Xưởng", "Hộp Đóng Gói"].map((item) => (
                <li key={item}>
                  <a href="#" className="text-[11px] md:text-[12.5px] text-[#bbb] hover:text-[#22c55e] transition-colors">
                    {item}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">Liên hệ</h5>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <MapPin className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              <div>
                <p>{"Văn phòng: 125 đường số 5, KDC Vĩnh Lộc, Phường Bình Tân, TP. Hồ Chí Minh"}</p>
                <p className="mt-1">{"Nhà Máy: Lô A7, CCN Nhị Xuân, Xã Xuân Thới Sơn, TP. Hồ Chí Minh"}</p>
              </div>
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <Phone className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              0373 122 528 - 0865 108 823
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs">
              <Mail className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              salesmebox.vn@gmail.com
            </div>
          </div>
        </div>
        <div className="border-t border-[#2d2d4e] pt-4 md:pt-5 flex flex-col md:flex-row justify-between items-center gap-3">
          <div className="flex gap-2.5">
            <div className="bg-[#2d2d4e] rounded px-2 md:px-3 py-1 md:py-1.5 text-[9px] md:text-[10px] font-bold text-[#ccc] border border-[#3d3d5e]">DMCA</div>
            <div className="bg-[#2d2d4e] rounded px-2 md:px-3 py-1 md:py-1.5 text-[9px] md:text-[10px] font-bold text-[#ccc] border border-[#3d3d5e]">PROTECTED</div>
          </div>
          <p className="text-[11px] md:text-xs text-[#888]">
            © Bản quyền thuộc về <strong className="text-[#22c55e]">MeBox</strong> – Phiên bản 1.0
          </p>
        </div>
      </footer>

      {/* FLOATING BUTTONS */}
      <div className="fixed right-3 md:right-6 bottom-16 md:bottom-20 flex flex-col gap-2 md:gap-3 z-50">
        {/* Zalo Button - Prominent */}
        <a 
          href="https://zalo.me/0373122528" 
          target="_blank"
          rel="noopener noreferrer"
          className="relative group"
        >
          <div className="absolute inset-0 bg-[#0068ff] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#0068ff] to-[#0050cc] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <span className="font-black text-xs md:text-sm">Zalo</span>
          </div>
          <div className="hidden md:block absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-[#0068ff] text-white px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
            Chat Zalo ngay!
            <div className="absolute right-0 top-1/2 -translate-y-1/2 translate-x-1 w-2 h-2 bg-[#0068ff] rotate-45" />
          </div>
        </a>
        {/* Messenger Button */}
        <a href="#" className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-[#0084ff] text-white flex items-center justify-center shadow-lg hover:scale-110 transition-transform">
          <MessageCircle className="w-4 h-4 md:w-5 md:h-5" />
        </a>
        {/* Phone Button */}
        <a href="tel:0373122528" className="w-10 h-10 md:w-11 md:h-11 rounded-full bg-[#22c55e] text-white flex items-center justify-center shadow-lg hover:scale-110 transition-transform">
          <Phone className="w-4 h-4 md:w-5 md:h-5" />
        </a>
      </div>
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
        className="fixed right-3 md:right-6 bottom-3 md:bottom-6 w-9 h-9 md:w-10 md:h-10 rounded-full bg-[#22c55e] text-white flex items-center justify-center shadow-lg hover:scale-110 transition-transform z-50"
      >
        <ArrowUp className="w-4 h-4 md:w-4.5 md:h-4.5" />
      </button>
    </div>
  )
}
