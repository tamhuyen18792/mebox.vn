"use client"

import { useState } from "react"
import Image from "next/image"
import { Phone, Mail, MapPin, Search, ShoppingCart, Menu, X, Truck, Clock, Package, RefreshCw, Shield, DollarSign, Headphones, Palette } from "lucide-react"

export default function ChinhSachBanHangPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const policies = [
    {
      icon: Truck,
      title: "Free Ship HCM",
      description: "Miễn phí vận chuyển nội thành TP. Hồ Chí Minh với đơn hàng từ 500.000đ trở lên."
    },
    {
      icon: Clock,
      title: "Giao hàng nhanh chóng trong 24h",
      description: "Cam kết giao hàng trong vòng 24 giờ kể từ khi xác nhận đơn hàng tại khu vực TP.HCM và các tỉnh lân cận."
    },
    {
      icon: Package,
      title: "Bốc xếp hàng hoá tận kho",
      description: "Hỗ trợ bốc xếp hàng hoá tận kho cho khách hàng, giúp tiết kiệm thời gian và công sức."
    },
    {
      icon: RefreshCw,
      title: "Đổi trả miễn phí",
      description: "Đổi trả miễn phí với bất kỳ lý do gì trong vòng 7 ngày kể từ ngày nhận hàng. Không cần giải thích."
    },
    {
      icon: Shield,
      title: "Cam kết chất lượng ổn định",
      description: "Cam kết hàng hoá chất lượng ổn định, không làm loại giấy kém chất lượng so với khi báo giá cho khách hàng."
    },
    {
      icon: DollarSign,
      title: "Giá cả ổn định",
      description: "Cam kết giá cả luôn ổn định trong thời gian dài, không tăng giá quá 10% trong thời gian ngắn."
    },
    {
      icon: Headphones,
      title: "Dịch vụ tư vấn miễn phí",
      description: "Cam kết dịch vụ tư vấn miễn phí, nhiệt tình, tận tâm phục vụ khách hàng 24/7."
    },
    {
      icon: Palette,
      title: "In miễn phí",
      description: "MeBox miễn phí in cho đơn hàng từ 5 triệu. Thiết kế mẫu mã sản phẩm theo yêu cầu của khách hàng."
    }
  ]

  return (
    <div className="bg-white min-h-screen font-sans text-[#333]">
      {/* TOP BAR */}
      <div className="bg-gradient-to-r from-[#1a1a2e] via-[#1e3a5f] to-[#1a1a2e] text-white text-xs md:text-sm">
        {/* Mobile Layout */}
        <div className="flex md:hidden px-3 py-2.5 justify-between items-center">
          <a href="tel:0373122528" className="flex items-center gap-1.5 text-[#22c55e] font-semibold">
            <Phone className="w-3.5 h-3.5" /> 0373 122 528
          </a>
          <div className="flex items-center gap-3">
            <a href="/chinh-sach-ban-hang" className="text-[#22c55e] font-medium">{"Chính sách"}</a>
            <a href="/gioi-thieu" className="text-white/80 hover:text-white transition-colors">{"Giới thiệu"}</a>
          </div>
        </div>
        {/* Desktop Layout */}
        <div className="hidden md:flex justify-between items-center px-4 lg:px-10 py-2.5">
          <div className="flex items-center gap-6 lg:gap-8">
            <a href="tel:0373122528" className="flex items-center gap-2 hover:text-[#22c55e] transition-colors group">
              <div className="w-7 h-7 bg-[#22c55e] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-semibold">0373 122 528 - 0865 108 823</span>
            </a>
          </div>
          <div className="flex items-center gap-1">
            <a href="/" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Trang chủ"}</a>
            <a href="/chinh-sach-ban-hang" className="px-3 py-1.5 rounded-full bg-[#22c55e] text-white font-semibold text-xs hover:bg-[#16a34a] transition-colors">{"Chính sách bán hàng"}</a>
            <a href="/gioi-thieu" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Giới thiệu"}</a>
            <a href="/san-pham" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Sản phẩm"}</a>
            <a href="/tin-tuc" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Tin tức"}</a>
            <a href="/lien-he" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Liên hệ"}</a>
          </div>
        </div>
      </div>

      {/* HEADER */}
      <header className="border-b border-[#e8e8e8] sticky top-0 bg-white z-50">
        <nav className="flex justify-between items-center px-4 md:px-10 py-2.5 md:py-0">
          <a href="/" className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-removebg-preview%20%5BMConverter.eu%5D-LqMoskWmc0rf6ShvkvPHYnuPqoKalj.webp"
              alt="MeBox Logo"
              width={90}
              height={36}
              className="h-8 md:h-10 w-auto"
            />
          </a>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex">
            {["Trang chủ", "Chính sách bán hàng", "Sản phẩm", "Giới thiệu", "Tin tức", "Liên hệ"].map((item, i) => (
              <a
                key={item}
                href={item === "Trang chủ" ? "/" : item === "Chính sách bán hàng" ? "/chinh-sach-ban-hang" : item === "Giới thiệu" ? "/gioi-thieu" : item === "Sản phẩm" ? "/san-pham" : item === "Tin tức" ? "/tin-tuc" : item === "Liên hệ" ? "/lien-he" : "#"}
                className={`px-3 lg:px-4 py-[18px] text-[12px] lg:text-[13.5px] font-semibold border-b-[3px] -mb-[3px] transition-colors ${
                  i === 1 ? "text-[#22c55e] border-[#22c55e]" : "text-[#333] border-transparent hover:text-[#22c55e] hover:border-[#22c55e]"
                }`}
              >
                {item}
              </a>
            ))}
          </div>
          
          <div className="flex gap-3 md:gap-4 items-center">
            <Search className="w-5 h-5 text-[#555] cursor-pointer" />
            <ShoppingCart className="w-5 h-5 text-[#555] cursor-pointer" />
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-1"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </nav>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-[#eee] shadow-lg">
            {["Trang chủ", "Chính sách bán hàng", "Sản phẩm", "Giới thiệu", "Tin tức", "Liên hệ"].map((item, i) => (
              <a
                key={item}
                href={item === "Trang chủ" ? "/" : item === "Chính sách bán hàng" ? "/chinh-sach-ban-hang" : item === "Giới thiệu" ? "/gioi-thieu" : item === "Sản phẩm" ? "/san-pham" : item === "Tin tức" ? "/tin-tuc" : item === "Liên hệ" ? "/lien-he" : "#"}
                onClick={() => setMobileMenuOpen(false)}
                className={`block px-4 py-3 text-sm font-semibold border-b border-[#f0f0f0] ${
                  i === 1 ? "text-[#22c55e]" : "text-[#333]"
                }`}
              >
                {item}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* HERO BANNER */}
      <section className="bg-[#1a5276] py-10 md:py-16 px-4 md:px-10">
        <div className="max-w-[1400px] mx-auto text-center">
          <h1 className="text-2xl md:text-4xl font-black text-[#ffd700] uppercase mb-4">
            Chính Sách Bán Hàng
          </h1>
          <p className="text-white text-sm md:text-lg max-w-2xl mx-auto">
            MeBox cam kết mang đến dịch vụ tốt nhất cho khách hàng với các chính sách ưu đãi hấp dẫn
          </p>
        </div>
      </section>

      {/* POLICIES SECTION */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-[#f9f9f9]">
        <div className="max-w-[1400px] mx-auto">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {policies.map((policy, index) => (
              <div 
                key={index}
                className="bg-white rounded-xl p-6 shadow-md hover:shadow-lg transition-shadow border-t-4 border-[#22c55e]"
              >
                <div className="w-14 h-14 bg-[#1a5276] rounded-full flex items-center justify-center mb-4">
                  <policy.icon className="w-7 h-7 text-[#ffd700]" />
                </div>
                <h3 className="text-base md:text-lg font-bold text-[#1a5276] mb-2">{policy.title}</h3>
                <p className="text-sm text-[#666] leading-relaxed">{policy.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* COMMITMENT BANNER */}
      <section className="bg-[#22c55e] py-8 md:py-12 px-4 md:px-10">
        <div className="max-w-[1400px] mx-auto text-center">
          <h2 className="text-xl md:text-2xl font-black text-white uppercase mb-4">
            Cam Kết Của MeBox
          </h2>
          <p className="text-white text-sm md:text-base max-w-3xl mx-auto leading-relaxed">
            Chúng tôi luôn đặt lợi ích của khách hàng lên hàng đầu. Mọi sản phẩm đều được kiểm tra chất lượng nghiêm ngặt trước khi giao đến tay khách hàng. Đội ngũ nhân viên chuyên nghiệp, tận tâm sẵn sàng hỗ trợ bạn 24/7.
          </p>
        </div>
      </section>

      {/* WHOLESALE PRICING SECTION */}
      <section id="wholesale-pricing" className="py-10 md:py-16 px-4 md:px-10 bg-white">
        <div className="max-w-[1400px] mx-auto mb-3 md:mb-4">
          <div className="bg-[#1a5276] rounded-t-xl px-6 md:px-10 py-6 md:py-8 text-center shadow-lg">
            <h2 className="text-xl md:text-2xl font-black uppercase text-[#ffd700]">
              BẢNG GIÁ KHÁCH SỈ
            </h2>
            <p className="text-white text-sm md:text-base mt-3 font-medium">{"Ưu đãi đặc biệt dành cho đối tác và khách hàng mua số lượng lớn"}</p>
            <p className="text-[#ffd700] text-xs md:text-sm mt-2 font-semibold">(Giá đã bao gồm VAT)</p>
          </div>
        </div>
        <div className="max-w-[1400px] mx-auto">
          <img 
            src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/b%E1%BA%A3ng%20b%C3%A1o%20gi%C3%A1%20th%C3%A1ng%204.2026-zbaGb9VQAKcNCIZIONULBM3kQK8nqd.jpg"
            alt="Bảng báo giá hộp carton MeBox tháng 4/2026"
            className="w-full h-auto rounded-lg shadow-lg"
          />
        </div>
      </section>

      {/* CONTACT CTA */}
      <section className="bg-[#1a5276] py-10 md:py-14 px-4 md:px-10">
        <div className="max-w-[1400px] mx-auto text-center">
          <h2 className="text-xl md:text-2xl font-black text-[#ffd700] uppercase mb-4">
            {"Bạn cần tư vấn thêm?"}
          </h2>
          <p className="text-white text-sm md:text-base mb-6">
            {"Liên hệ ngay với chúng tôi để được hỗ trợ nhanh nhất"}
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
            <a 
              href="tel:0373122528"
              className="bg-[#22c55e] text-white px-8 py-3 rounded-full font-bold text-sm md:text-base hover:bg-[#16a34a] transition-colors flex items-center gap-2"
            >
              <Phone className="w-5 h-5" />
              0373 122 528
            </a>
            <a 
              href="https://zalo.me/0373122528"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#0068ff] text-white px-8 py-3 rounded-full font-bold text-sm md:text-base hover:bg-[#0055cc] transition-colors"
            >
              Chat Zalo
            </a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#1a1a2e] text-[#ccc] py-8 md:py-12 px-4 md:px-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 mb-6 md:mb-10">
          <div className="col-span-2 md:col-span-1">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-removebg-preview%20%5BMConverter.eu%5D-LqMoskWmc0rf6ShvkvPHYnuPqoKalj.webp"
              alt="MeBox Logo"
              width={100}
              height={40}
              className="h-8 md:h-10 w-auto mb-3 md:mb-4 brightness-0 invert"
            />
            <p className="text-[12px] md:text-[12.5px] leading-relaxed mb-4">
              {"MeBox - Chuyên cung cấp các giải pháp gia công bao bì chất lượng cao, phục vụ cho hàng trăm doanh nghiệp, hộ kinh doanh và các shop Online."}
            </p>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">Mục Lục</h5>
            <ul className="text-[11px] md:text-xs space-y-2">
              {["Giới thiệu", "Tin tức", "Tuyển dụng", "Liên hệ"].map((item) => (
                <li key={item}><a href="#" className="hover:text-[#22c55e] transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">Sản phẩm</h5>
            <ul className="text-[11px] md:text-xs space-y-2">
              {["Hộp Carton Giá Sỉ", "Hộp Carton Online", "Hộp Carton Giá Xưởng", "Hộp Đóng Gói"].map((item) => (
                <li key={item}><a href="#" className="hover:text-[#22c55e] transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">Liên hệ</h5>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <MapPin className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              <div>
                <p>{"Văn phòng: 125 đường số 5, KDC Vĩnh Lộc, Phường Bình Tân, TP. Hồ Chí Minh"}</p>
                <p className="mt-1">{"Nhà Máy: Lô A7, CCN Nhị Xuân, Xã Xuân Thới Sơn, TP. Hồ Chí Minh"}</p>
              </div>
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <Phone className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              0373 122 528 - 0865 108 823
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs">
              <Mail className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              salesmebox.vn@gmail.com
            </div>
          </div>
        </div>
        <div className="border-t border-[#333] pt-5 md:pt-6 flex flex-col md:flex-row justify-between items-center gap-3">
          <p className="text-[10px] md:text-xs text-center md:text-left">© 2026 MeBox. All rights reserved.</p>
        </div>
      </footer>

      {/* FLOATING BUTTONS */}
      <div className="fixed bottom-4 md:bottom-6 right-4 md:right-6 flex flex-col gap-2 md:gap-3 z-50">
        <a 
          href="https://zalo.me/0373122528" 
          target="_blank" 
          rel="noopener noreferrer"
          className="group relative"
        >
          <div className="absolute inset-0 bg-[#0068ff] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#0068ff] to-[#0050cc] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <span className="font-black text-xs md:text-sm">Zalo</span>
          </div>
          <div className="hidden md:block absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-[#0068ff] text-white px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
            Chat Zalo ngay!
          </div>
        </a>
        <a 
          href="tel:0373122528"
          className="group relative w-12 h-12 md:w-14 md:h-14 bg-[#22c55e] rounded-full flex items-center justify-center shadow-lg hover:scale-110 transition-transform animate-pulse"
        >
          <Phone className="w-5 h-5 md:w-6 md:h-6 text-white" />
          <span className="absolute right-full mr-2 px-2 py-1 bg-[#333] text-white text-xs rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity">
            0373 122 528
          </span>
        </a>
      </div>
    </div>
  )
}
