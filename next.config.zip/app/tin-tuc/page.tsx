"use client"

import { useState } from "react"
import Image from "next/image"
import { Phone, Mail, MapPin, Search, ShoppingCart, Menu, X, Calendar, User, ArrowRight, Clock } from "lucide-react"

export default function TinTucPage() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const featuredNews = {
    title: "MeBox ra mắt dòng sản phẩm hộp carton thân thiện môi trường",
    excerpt: "MeBox chính thức giới thiệu dòng sản phẩm hộp carton 100% tái chế, đáp ứng nhu cầu bảo vệ môi trường của doanh nghiệp hiện đại.",
    date: "05/04/2026",
    author: "MeBox Team",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20x15x10-bosiCJm4lpcmfsQrFEHCuhTQBpNjH9.png"
  }

  const news = [
    {
      title: "Hướng dẫn chọn kích thước hộp carton phù hợp cho shop online",
      excerpt: "Bài viết chia sẻ kinh nghiệm lựa chọn kích thước hộp carton phù hợp với từng loại sản phẩm, giúp tiết kiệm chi phí vận chuyển.",
      date: "03/04/2026",
      author: "MeBox Team",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/15x12x10-jHVydyxXxOoGrdtGN5acpMSShIR6W4.png"
    },
    {
      title: "5 lý do nên chọn hộp carton 3 lớp cho đóng gói hàng hóa",
      excerpt: "Khám phá những ưu điểm vượt trội của hộp carton 3 lớp trong việc bảo vệ sản phẩm và tối ưu chi phí đóng gói.",
      date: "01/04/2026",
      author: "MeBox Team",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20x10x10-fS6xv4JCx5ktZgTaOWmJDpfIGQ6o7s.png"
    },
    {
      title: "MeBox mở rộng nhà máy sản xuất tại Nhị Xuân",
      excerpt: "Nhằm đáp ứng nhu cầu ngày càng tăng, MeBox chính thức mở rộng quy mô nhà máy sản xuất với công suất gấp đôi.",
      date: "28/03/2026",
      author: "MeBox Team",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/22x17x11-fZVwVvTDFxDHtzniRpvPemp8jOji3U.png"
    },
    {
      title: "Xu hướng bao bì carton năm 2026: Bền vững và thông minh",
      excerpt: "Cập nhật những xu hướng mới nhất trong ngành bao bì carton, từ vật liệu tái chế đến công nghệ in ấn hiện đại.",
      date: "25/03/2026",
      author: "MeBox Team",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/20x20x15-qSBbwzE6MSAF4pSoO4VM8WZhstsL7R.png"
    },
    {
      title: "Cách bảo quản hộp carton đúng cách để tái sử dụng",
      excerpt: "Hướng dẫn chi tiết cách bảo quản hộp carton sau khi sử dụng để có thể tái sử dụng nhiều lần, tiết kiệm chi phí.",
      date: "22/03/2026",
      author: "MeBox Team",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/18x12x8-iLcrPlUOq134lsaV6U43vOii4nk41y.png"
    },
    {
      title: "MeBox tri ân khách hàng nhân dịp 4 năm thành lập",
      excerpt: "Chương trình khuyến mãi đặc biệt giảm giá 15% tất cả sản phẩm nhân dịp kỷ niệm 4 năm thành lập công ty.",
      date: "20/03/2026",
      author: "MeBox Team",
      image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/12x8x8-kk8sAlu7LvTIIeD8PrGYod72UvbyAt.png"
    }
  ]

  return (
    <div className="bg-white min-h-screen font-sans text-[#333]">
      {/* TOP BAR */}
      <div className="bg-gradient-to-r from-[#1a1a2e] via-[#1e3a5f] to-[#1a1a2e] text-white text-xs md:text-sm">
        {/* Mobile Layout */}
        <div className="flex md:hidden px-3 py-2.5 justify-between items-center">
          <a href="tel:0373122528" className="flex items-center gap-1.5 text-[#22c55e] font-semibold">
            <Phone className="w-3.5 h-3.5" /> 0373 122 528
          </a>
          <div className="flex items-center gap-3">
            <a href="/chinh-sach-ban-hang" className="text-[#ffd700] font-medium hover:text-white transition-colors">{"Chính sách"}</a>
            <a href="/gioi-thieu" className="text-white/80 hover:text-white transition-colors">{"Giới thiệu"}</a>
          </div>
        </div>
        {/* Desktop Layout */}
        <div className="hidden md:flex justify-between items-center px-4 lg:px-10 py-2.5">
          <div className="flex items-center gap-6 lg:gap-8">
            <a href="tel:0373122528" className="flex items-center gap-2 hover:text-[#22c55e] transition-colors group">
              <div className="w-7 h-7 bg-[#22c55e] rounded-full flex items-center justify-center group-hover:scale-110 transition-transform">
                <Phone className="w-3.5 h-3.5 text-white" />
              </div>
              <span className="font-semibold">0373 122 528 - 0865 108 823</span>
            </a>
          </div>
          <div className="flex items-center gap-1">
            <a href="/" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Trang chủ"}</a>
            <a href="/chinh-sach-ban-hang" className="px-3 py-1.5 rounded-full text-[#ffd700] font-semibold text-xs hover:bg-white/10 transition-colors">{"Chính sách bán hàng"}</a>
            <a href="/gioi-thieu" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Giới thiệu"}</a>
            <a href="/san-pham" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Sản phẩm"}</a>
            <a href="/tin-tuc" className="px-3 py-1.5 rounded-full bg-[#22c55e] text-white font-semibold text-xs hover:bg-[#16a34a] transition-colors">{"Tin tức"}</a>
            <a href="/lien-he" className="px-3 py-1.5 rounded-full text-white/90 text-xs hover:bg-white/10 transition-colors">{"Liên hệ"}</a>
          </div>
        </div>
      </div>

      {/* HEADER */}
      <header className="border-b border-[#e8e8e8] sticky top-0 bg-white z-50">
        <nav className="flex justify-between items-center px-4 md:px-10 py-2.5 md:py-0">
          <a href="/" className="flex items-center gap-2">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-removebg-preview%20%5BMConverter.eu%5D-LqMoskWmc0rf6ShvkvPHYnuPqoKalj.webp"
              alt="MeBox Logo"
              width={90}
              height={36}
              className="h-8 md:h-10 w-auto"
            />
          </a>
          
          {/* Desktop Menu */}
          <div className="hidden md:flex">
            {["Trang chủ", "Chính sách bán hàng", "Sản phẩm", "Giới thiệu", "Tin tức", "Liên hệ"].map((item, i) => (
              <a
                key={item}
                href={item === "Trang chủ" ? "/" : item === "Chính sách bán hàng" ? "/chinh-sach-ban-hang" : item === "Giới thiệu" ? "/gioi-thieu" : item === "Sản phẩm" ? "/san-pham" : item === "Tin tức" ? "/tin-tuc" : item === "Liên hệ" ? "/lien-he" : "#"}
                className={`px-3 lg:px-4 py-[18px] text-[12px] lg:text-[13.5px] font-semibold border-b-[3px] -mb-[3px] transition-colors ${
                  i === 4 ? "text-[#22c55e] border-[#22c55e]" : "text-[#333] border-transparent hover:text-[#22c55e] hover:border-[#22c55e]"
                }`}
              >
                {item}
              </a>
            ))}
          </div>
          
          <div className="flex gap-3 md:gap-4 items-center">
            <Search className="w-5 h-5 text-[#555] cursor-pointer" />
            <ShoppingCart className="w-5 h-5 text-[#555] cursor-pointer" />
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-1"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </nav>

        {/* Mobile Menu Dropdown */}
        {mobileMenuOpen && (
          <div className="md:hidden bg-white border-b border-[#eee] shadow-lg">
            {["Trang chủ", "Chính sách bán hàng", "Sản phẩm", "Giới thiệu", "Tin tức", "Liên hệ"].map((item, i) => (
              <a
                key={item}
                href={item === "Trang chủ" ? "/" : item === "Chính sách bán hàng" ? "/chinh-sach-ban-hang" : item === "Giới thiệu" ? "/gioi-thieu" : item === "Sản phẩm" ? "/san-pham" : item === "Tin tức" ? "/tin-tuc" : item === "Liên hệ" ? "/lien-he" : "#"}
                onClick={() => setMobileMenuOpen(false)}
                className={`block px-4 py-3 text-sm font-semibold border-b border-[#f0f0f0] ${
                  i === 4 ? "text-[#22c55e]" : "text-[#333]"
                }`}
              >
                {item}
              </a>
            ))}
          </div>
        )}
      </header>

      {/* HERO BANNER */}
      <section className="bg-[#1a5276] py-10 md:py-16 px-4 md:px-10">
        <div className="max-w-[1400px] mx-auto text-center">
          <h1 className="text-2xl md:text-4xl font-black text-[#ffd700] uppercase mb-4">
            Tin Tức & Blog
          </h1>
          <p className="text-white text-sm md:text-lg max-w-2xl mx-auto">
            Cập nhật những thông tin mới nhất về sản phẩm, xu hướng ngành bao bì và các hoạt động của MeBox
          </p>
        </div>
      </section>

      {/* FEATURED NEWS */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-[#f9f9f9]">
        <div className="max-w-[1400px] mx-auto">
          <h2 className="text-xl md:text-2xl font-black text-[#1a5276] uppercase mb-6 md:mb-8 text-center">
            Tin Nổi Bật
          </h2>
          <div className="bg-white rounded-xl overflow-hidden shadow-lg hover:shadow-xl transition-shadow">
            <div className="grid md:grid-cols-2 gap-0">
              <div className="h-64 md:h-auto overflow-hidden">
                <img 
                  src={featuredNews.image}
                  alt={featuredNews.title}
                  className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                />
              </div>
              <div className="p-6 md:p-10 flex flex-col justify-center">
                <div className="flex items-center gap-4 text-sm text-[#666] mb-4">
                  <span className="flex items-center gap-1.5">
                    <Calendar className="w-4 h-4 text-[#22c55e]" />
                    {featuredNews.date}
                  </span>
                  <span className="flex items-center gap-1.5">
                    <User className="w-4 h-4 text-[#22c55e]" />
                    {featuredNews.author}
                  </span>
                </div>
                <h3 className="text-xl md:text-2xl font-bold text-[#1a5276] mb-4 hover:text-[#22c55e] transition-colors cursor-pointer">
                  {featuredNews.title}
                </h3>
                <p className="text-[#666] leading-relaxed mb-6">
                  {featuredNews.excerpt}
                </p>
                <a href="#" className="inline-flex items-center gap-2 text-[#22c55e] font-semibold hover:gap-3 transition-all">
                  Đọc tiếp <ArrowRight className="w-4 h-4" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* NEWS GRID */}
      <section className="py-10 md:py-16 px-4 md:px-10 bg-white">
        <div className="max-w-[1400px] mx-auto">
          <h2 className="text-xl md:text-2xl font-black text-[#1a5276] uppercase mb-6 md:mb-8 text-center">
            Bài Viết Mới Nhất
          </h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {news.map((item, index) => (
              <article 
                key={index}
                className="bg-white rounded-xl overflow-hidden shadow-md hover:shadow-lg transition-shadow border border-[#eee]"
              >
                <div className="h-48 overflow-hidden">
                  <img 
                    src={item.image}
                    alt={item.title}
                    className="w-full h-full object-cover hover:scale-105 transition-transform duration-500"
                  />
                </div>
                <div className="p-5">
                  <div className="flex items-center gap-3 text-xs text-[#888] mb-3">
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3.5 h-3.5" />
                      {item.date}
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      3 phút đọc
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-[#1a5276] mb-2 line-clamp-2 hover:text-[#22c55e] transition-colors cursor-pointer">
                    {item.title}
                  </h3>
                  <p className="text-sm text-[#666] line-clamp-2 mb-4">
                    {item.excerpt}
                  </p>
                  <a href="#" className="inline-flex items-center gap-1.5 text-[#22c55e] text-sm font-semibold hover:gap-2.5 transition-all">
                    Đọc tiếp <ArrowRight className="w-3.5 h-3.5" />
                  </a>
                </div>
              </article>
            ))}
          </div>
          
          {/* Load More Button */}
          <div className="text-center mt-10">
            <button className="bg-[#1a5276] text-white px-8 py-3 rounded-full font-semibold hover:bg-[#154360] transition-colors">
              Xem thêm bài viết
            </button>
          </div>
        </div>
      </section>

      {/* NEWSLETTER SUBSCRIPTION */}
      <section className="bg-[#22c55e] py-10 md:py-14 px-4 md:px-10">
        <div className="max-w-[1400px] mx-auto text-center">
          <h2 className="text-xl md:text-2xl font-black text-white uppercase mb-4">
            Đăng Ký Nhận Tin
          </h2>
          <p className="text-white/90 text-sm md:text-base mb-6 max-w-2xl mx-auto">
            Đăng ký để nhận thông tin khuyến mãi, sản phẩm mới và các tin tức hữu ích từ MeBox
          </p>
          <div className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <input 
              type="email" 
              placeholder="Nhập email của bạn..."
              className="flex-1 px-5 py-3 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-white/50"
            />
            <button className="bg-[#1a5276] text-white px-8 py-3 rounded-full font-semibold hover:bg-[#154360] transition-colors whitespace-nowrap">
              Đăng ký
            </button>
          </div>
        </div>
      </section>

      {/* CONTACT CTA */}
      <section className="bg-[#1a5276] py-10 md:py-14 px-4 md:px-10">
        <div className="max-w-[1400px] mx-auto text-center">
          <h2 className="text-xl md:text-2xl font-black text-[#ffd700] uppercase mb-4">
            {"Bạn cần tư vấn thêm?"}
          </h2>
          <p className="text-white text-sm md:text-base mb-6">
            {"Liên hệ ngay với chúng tôi để được hỗ trợ nhanh nhất"}
          </p>
          <div className="flex flex-col md:flex-row gap-4 justify-center items-center">
            <a 
              href="tel:0373122528"
              className="bg-[#22c55e] text-white px-8 py-3 rounded-full font-bold text-sm md:text-base hover:bg-[#16a34a] transition-colors flex items-center gap-2"
            >
              <Phone className="w-5 h-5" />
              0373 122 528
            </a>
            <a 
              href="https://zalo.me/0373122528"
              target="_blank"
              rel="noopener noreferrer"
              className="bg-[#0068ff] text-white px-8 py-3 rounded-full font-bold text-sm md:text-base hover:bg-[#0055cc] transition-colors"
            >
              Chat Zalo
            </a>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-[#1a1a2e] text-[#ccc] py-8 md:py-12 px-4 md:px-10">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 md:gap-8 mb-6 md:mb-10">
          <div className="col-span-2 md:col-span-1">
            <Image
              src="https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-removebg-preview%20%5BMConverter.eu%5D-LqMoskWmc0rf6ShvkvPHYnuPqoKalj.webp"
              alt="MeBox Logo"
              width={100}
              height={40}
              className="h-8 md:h-10 w-auto mb-3 md:mb-4 brightness-0 invert"
            />
            <p className="text-[12px] md:text-[12.5px] leading-relaxed mb-4">
              {"MeBox - Chuyên cung cấp các giải pháp gia công bao bì chất lượng cao, phục vụ cho hàng trăm doanh nghiệp, hộ kinh doanh và các shop Online."}
            </p>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">Mục Lục</h5>
            <ul className="text-[11px] md:text-xs space-y-2">
              {["Giới thiệu", "Tin tức", "Tuyển dụng", "Liên hệ"].map((item) => (
                <li key={item}><a href={item === "Tin tức" ? "/tin-tuc" : item === "Giới thiệu" ? "/gioi-thieu" : "#"} className="hover:text-[#22c55e] transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">Sản phẩm</h5>
            <ul className="text-[11px] md:text-xs space-y-2">
              {["Hộp Carton Giá Sỉ", "Hộp Carton Online", "Hộp Carton Giá Xưởng", "Hộp Đóng Gói"].map((item) => (
                <li key={item}><a href="/san-pham" className="hover:text-[#22c55e] transition-colors">{item}</a></li>
              ))}
            </ul>
          </div>
          <div>
            <h5 className="text-white text-[13px] md:text-sm font-bold mb-3 md:mb-4 uppercase tracking-wide">Liên hệ</h5>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <MapPin className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              <div>
                <p>{"Văn phòng: 125 đường số 5, KDC Vĩnh Lộc, Phường Bình Tân, TP. Hồ Chí Minh"}</p>
                <p className="mt-1">{"Nhà Máy: Lô A7, CCN Nhị Xuân, Xã Xuân Thới Sơn, TP. Hồ Chí Minh"}</p>
              </div>
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs mb-2">
              <Phone className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              0373 122 528 - 0865 108 823
            </div>
            <div className="flex items-start gap-2 text-[11px] md:text-xs">
              <Mail className="w-3.5 min-w-[14px] mt-0.5 text-[#22c55e]" />
              salesmebox.vn@gmail.com
            </div>
          </div>
        </div>
        <div className="border-t border-[#333] pt-5 md:pt-6 flex flex-col md:flex-row justify-between items-center gap-3">
          <p className="text-[10px] md:text-xs text-center md:text-left">© 2026 MeBox. All rights reserved.</p>
        </div>
      </footer>

      {/* FLOATING BUTTONS */}
      <div className="fixed bottom-4 md:bottom-6 right-4 md:right-6 flex flex-col gap-2 md:gap-3 z-50">
        <a 
          href="https://zalo.me/0373122528" 
          target="_blank" 
          rel="noopener noreferrer"
          className="group relative"
        >
          <div className="absolute inset-0 bg-[#0068ff] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#0068ff] to-[#0050cc] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <span className="font-black text-xs md:text-sm">Zalo</span>
          </div>
          <div className="hidden md:block absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-[#0068ff] text-white px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
            Chat Zalo ngay!
          </div>
        </a>
        <a 
          href="tel:0373122528"
          className="group relative"
        >
          <div className="absolute inset-0 bg-[#22c55e] rounded-full animate-ping opacity-30" />
          <div className="relative w-12 h-12 md:w-14 md:h-14 rounded-full bg-gradient-to-br from-[#22c55e] to-[#16a34a] text-white flex items-center justify-center shadow-xl hover:scale-110 transition-transform border-2 border-white">
            <Phone className="w-5 h-5 md:w-6 md:h-6" />
          </div>
          <div className="hidden md:block absolute right-full mr-3 top-1/2 -translate-y-1/2 bg-[#22c55e] text-white px-3 py-2 rounded-lg text-xs font-bold whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity shadow-lg">
            Gọi ngay!
          </div>
        </a>
      </div>
    </div>
  )
}
